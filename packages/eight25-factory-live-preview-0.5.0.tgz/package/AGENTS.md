# AI-agent instructions

Two documents address agents. **This file** is for wiring the package into an
application. **[SKILLS.md](SKILLS.md)** is for building or changing components
once the wiring exists; install it into the project with
`npx live-preview install-skills` so it is found at
`.claude/skills/live-preview/SKILL.md`.

## Working in an application

Install from npm by default. `init --write` adds this package and the CMS SDK
to `package.json` with the project's own package manager, so the manual
install is only needed when running with `--no-install` or without `--write`:

```sh
npx @eight25-factory/live-preview init --write   # installs the two lines below itself
npm install @eight25-factory/live-preview
npm install @contentful/live-preview            # Contentful projects
npm install @contentstack/live-preview-utils    # Contentstack projects
```

On a Next project `init --write` also patches `next.config.*` and
`app/layout.tsx` when they still have the create-next-app shape (`--no-patch`
to skip). If the application already has its own Contentful or Contentstack
client, run `init --write --no-fetch-helpers` and pass `state.active` into
that client as the preview flag instead of adding a second client. After
wiring, run `npx live-preview doctor <base-url>` against the running app: it
checks the draft cookie's attributes (the `next dev` cookie is `SameSite=Lax`
and is withheld inside the Contentful frame unless the generated enable route
re-issues it), the tags, framing and cache headers.

When the user explicitly requests a vendored install, or the application
already contains `packages/live-preview`, use the
[local folder installation](docs/local-install.md) instead, starting from the
tarball attached to the GitHub Release. Never add the repository's git URL as
a dependency: it carries TypeScript source and no `dist/`. Never switch
installation sources silently.

Before configuring, read [docs/api-reference.md](docs/api-reference.md) for
the exact public API, [docs/lifecycle.md](docs/lifecycle.md) for what runs on
the server, in the browser, and in the editor, and the framework page
([docs/nextjs.md](docs/nextjs.md) or [docs/nuxt.md](docs/nuxt.md)) for whole
files to adapt rather than fragments to compose.

## The gates

Work through these in order. `npx live-preview init` implements them and
`nextSetupQuestion` exposes them programmatically; prefer running that flow
over improvising.

### Gate 0 — is preview already wired?

Look for `live-preview.config.mjs`, an existing `ContentfulLivePreviewProvider`
or `ContentstackLivePreview.init` call, a `draftMode()` route, or
`data-cslp` / `data-contentful-*` attributes in components. On any signal,
**stop and ask** whether to migrate the existing wiring to this package,
extend it, or leave it. Two initializations of the same SDK on one page break
both. Default to not installing.

### Gate 1 — framework and version

Next or Nuxt, and the major version, from `package.json`. Next 13–15 and 16
are both supported; the generated files use the App Router.

### Gate 2 — CMS

Contentful or Contentstack only from explicit evidence: the SDK in
`package.json`, or the provider's environment variable **names**. Never infer
from a network probe. Run `npx live-preview check-env`.

### Gate 3 — how data is fetched

REST or GraphQL, official client or `fetch`, and where: Server Components,
route handlers, Nuxt server utils, or the browser. Preview only works when
**every** CMS request for a previewed page follows the preview state. Find the
data layer's single entry point; if there is none, say so before continuing.

### Gate 4 — caching

Find every cache the previewed page passes through: Next Data Cache /
`revalidate`, ISR, Nitro `routeRules`, CDN rules. Preview responses must be
`no-store` at every layer. The generated helpers handle the application layer;
ask about the CDN.

### Gate 5 — framing

Find every place `X-Frame-Options` or `Content-Security-Policy` is set: app
config, middleware, host dashboard, CDN. `withLivePreview` and the generated
Nuxt middleware handle the application layer; a host-level `DENY` still
blanks the preview panel and is the first thing to check when it does.

### Gate 6 — locale model

How the site represents locales (URL prefix, domain, none) and what the CMS
locale codes are. Contentful defaults to `en-US`; Contentstack tags use
lowercase codes (`en-us`). Multi-locale sites pass the page locale to
`getLivePreviewClientConfig(locale)` and to the taggers.

### Gate 7 — secrets

Confirm the required variable **names** are set in `.env.local` and the host:
`npx live-preview check-env`. Never ask for, print, or record a value. The
preview secret and tokens are server-only; there is no `NEXT_PUBLIC_` form of
any of them, and the client config the package builds contains none.

## Required wiring

A configuration alone previews nothing. After `init --write`, an agent **MUST**
complete every step or state exactly which was left undone and why:

1. **Framing headers**: `withLivePreview(nextConfig, options)` in
   `next.config.mjs`, or the generated `server/middleware/live-preview.ts` in
   Nuxt.
2. **Provider / plugins**: `<LivePreviewProvider config={...}>` once in the
   root layout (Next), or both generated plugins present (Nuxt).
3. **Preview-aware fetching**: every CMS request on previewed pages uses the
   generated helpers or reproduces their behaviour (preview host/token when
   active, `no-store` when active).
4. **Preview state at the page**: Next pages call
   `getPreviewState(await searchParams)` once and pass `state` down;
   Contentstack cannot work without the `searchParams` argument.
5. **Preview URL in the CMS**: Contentful Content preview URL pointing at the
   enable route with `secret=` and `path=`; Contentstack Live Preview enabled
   with the site URL and a Preview token.
6. **Skill installed**: `npx live-preview install-skills`.

## Configuration placement

Non-secret options belong in `live-preview.config.mjs`. Credentials are
build-environment-only. Never add tokens, secrets, CMS responses, or cookies
to source, logs, fixtures, or documentation.

```js
// live-preview.config.mjs
export const livePreviewOptions = {
  provider: "contentful",
  framework: "next",
  contentful: { locale: "en-US", region: "default" },
  tags: { policy: "preview-only" }, // Do not change to "always" without saying why.
};
```

## Rules that hold everywhere

- **Tags only from the helpers.** Never hand-write `data-contentful-*` or
  `data-cslp`. Never change `tags.policy` to `always` to "make inspector work"
  — that means the preview state is not reaching the component; fix that.
- **One SDK initialization**, in the generated provider or plugin.
- **No caching while previewing**, at any layer you control.
- **No redirect out of the requested URL** during preview, and no stripping of
  the query string on internal navigation.
- **Raw records to components.** Live updates match by identity; transformed
  data cannot be updated. See SKILLS.md rules R2 and R3.
- **Verify in the editor** ([SKILLS.md](SKILLS.md) Skill 4) before reporting
  that preview works. If you cannot, say what you verified and what you could
  not.

## Prohibited behavior

Do not expose a token or the preview secret to the browser under any name. Do
not detect preview from a bare `?preview=true` unless
`detection.queryParameter` is deliberately configured behind authentication.
Do not initialize the SDK unconditionally in production. Do not convert Server
Components to Client Components solely to tag them.

## Working in this source repository

```sh
npm run validate   # format, type-check, build, test
npm run audit
```

Source lives twice on purpose: `src/` is the published package with relative
imports; `packages/*/src/` mirrors it with `@live-preview/*` workspace
specifiers. Regenerate the mirror with `node scripts/sync-mirror.mjs`;
`test/source-mirror.test.ts` fails when the two drift, and
`test/public-package.test.ts` fails if `dist/` references a workspace alias.
See [DEVELOPMENT.md](DEVELOPMENT.md).
