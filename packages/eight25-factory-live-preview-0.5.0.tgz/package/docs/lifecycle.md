# Lifecycle

What runs where, and when. Useful when something works locally and not on the
host, or works on one page and not another.

## Build time

- `live-preview.config.mjs` is parsed once by `loadNextLivePreview` /
  `loadNuxtLivePreview` (or `parseLivePreviewConfig`). Unknown keys throw,
  so a broken configuration fails the build, not the first request.
- `withLivePreview` (Next) adds the `frame-ancestors` header rule.
  `livePreviewPublicRuntimeConfig` (Nuxt) serializes the non-secret options.
- `npm run build` of this package also pre-renders `skills/live-preview/SKILL.md`
  from `SKILLS.md`.

Nothing contacts a CMS at build time.

## Server, per request

1. **Environment** is read once per server instance by
   `contentfulEnvironmentFromEnv` / `contentstackEnvironmentFromEnv` in the
   generated server module. Missing required names throw with the variable
   name. Values are never logged.
2. **Preview state** is resolved from the request:
   - Contentful: `draftMode().isEnabled` (Next) or the detection cookie (Nuxt).
   - Contentstack: the `live_preview` hash and companions in the query string.
   - Either: the detection cookie, or `detection.queryParameter` if configured.
     In Next the decision is memoized per request with React `cache`; the page
     seeds it with `searchParams`, nested Server Components read it back.
3. **Data fetching** follows the state: preview host and token when active,
   `cache: "no-store"` when active, the application's own caching otherwise.
4. **Tagging** happens during render with `previewTags` / `tagsFor`. Under
   `preview-only`, an inactive state yields `{}` and the HTML is identical to
   production.
5. **Client bootstrap**: `livePreviewClientConfig` (Next) /
   `livePreviewNuxtClientState` (Nuxt) builds the token-free object the
   provider or plugin needs, including the SDK `init` shape and the tagging
   context. Contentstack + Next: the layout cannot see the query string, so
   the bootstrap is inactive and the browser finishes it.
6. **Headers**: `frame-ancestors` on every response; `no-store` on preview
   responses (Nuxt middleware; Next through the fetch options and the route
   handlers).

## Browser, on load

- Outside preview: the provider renders children; no SDK code runs.
- Contentful, in preview: `ContentfulLivePreviewProvider` initializes the
  SDK with `init`; the provider subscribes to editor `save` events.
- Contentstack: `hydrateContentstackClient(config, location.search)` decides
  `active`, `builder`, the SDK `mode`, and the parameters to carry; then
  `ContentstackLivePreview.init(init)`; a capturing click listener appends
  the session parameters to same-origin links.

## Browser, while editing

| Event                  | Contentful                                                       | Contentstack                                                                                                                           |
| ---------------------- | ---------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------- |
| Editor keystroke       | SDK posts the changed entry; `useLiveEntry` components re-render | `ssr: true`: SDK fetches the URL with the new hash, patches the DOM. `ssr: false`: `onEntryChange` → route re-render with the new hash |
| Editor autosave / save | `save` event → `router.refresh()` / `refreshNuxtData()`          | same as above                                                                                                                          |
| Hover a tagged element | SDK outlines it, offers Edit                                     | SDK shows the Edit button; builder shows handles                                                                                       |
| Click an internal link | Draft mode cookie travels with the request                       | Click listener appends `live_preview`, `content_type_uid`, `entry_uid`, `builder`, …                                                   |

## Session end

Contentful: the disable route (`draftMode().disable()` or clearing the cookie)
and a redirect. Contentstack: closing the panel; the next request without a
hash is production.

## Caching summary

| Layer          | Preview                                                                                     | Production                        |
| -------------- | ------------------------------------------------------------------------------------------- | --------------------------------- |
| CMS request    | `no-store`                                                                                  | Application's `revalidate` / tags |
| Route handlers | `Cache-Control: no-store`                                                                   | n/a                               |
| Nuxt response  | `no-store` (middleware)                                                                     | Application's rules               |
| CDN / host     | **Outside the package.** Exclude requests carrying `live_preview` or the draft-mode cookie. | As configured                     |

## Failure behaviour

- Configuration errors throw `LivePreviewValidationError` with the offending
  path.
- Missing environment variables throw naming the variable.
- Tagging a record without identity throws, naming what to select in the
  query. This is deliberate: a silently untagged field is invisible until an
  editor complains.
- A rejected draft-mode request returns `401` (secret) or `400` (target) with
  `no-store`, and never redirects off-origin.
