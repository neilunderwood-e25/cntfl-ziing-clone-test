# Next.js

Complete wiring for the App Router. `npx live-preview init --write` generates
every file below and patches `next.config.*` and `app/layout.tsx` when they
still have the create-next-app shape; this page explains them so you can
adapt rather than rediscover. Paths assume no `src/` directory; with one,
prefix `src/`.

## What Next needs from you

1. The CMS may **frame** the site: `frame-ancestors` in the CSP, no
   `X-Frame-Options`.
2. The **provider** renders once, in the root layout, with a token-free config
   computed on the server (or `null` on an unconfigured checkout).
3. Every CMS request on a previewed page **follows the preview state**: preview
   host and token, no Data Cache.
4. Pages **resolve the preview state once** and pass it down.
5. Components **tag fields** with `previewTags` (server) or `useFieldTags`
   (client).
6. On a CDN-cached site, **draft-mode responses are `no-store`** (middleware).

## 1. Configuration

```js
// live-preview.config.mjs
/** @type {import("@eight25-factory/live-preview").LivePreviewConfigInput} */
export const livePreviewOptions = {
  provider: "contentful", // or "contentstack"
  framework: "next",
  contentful: { locale: "en-US", region: "default" },
};
```

```ts
// lib/live-preview/config.ts
import { loadNextLivePreview } from "@eight25-factory/live-preview/next";
import { livePreviewOptions } from "../../live-preview.config.mjs";

export const livePreviewConfig = loadNextLivePreview(livePreviewOptions);
```

The JSDoc `@type` keeps the literals (`"contentful"`, `"next"`) from widening
to `string` when TypeScript imports the `.mjs` file.

## 2. `next.config.ts` (or `.mjs`): let the CMS frame the site

`init --write` patches the default create-next-app file. By hand:

```ts
// next.config.ts
import type { NextConfig } from "next";
import { withLivePreview } from "@eight25-factory/live-preview/next";
import { livePreviewOptions } from "./live-preview.config.mjs";

const nextConfig: NextConfig = {/* your existing config */};

export default withLivePreview(nextConfig, livePreviewOptions);
```

```js
// next.config.mjs
import { withLivePreview } from "@eight25-factory/live-preview/next";
import { livePreviewOptions } from "./live-preview.config.mjs";

export default await withLivePreview(
  {/* your existing config */},
  livePreviewOptions,
);
```

`withLivePreview(nextConfig)` is typed `Promise<NextConfig>` for whatever
config type you pass in, and Next accepts a promise as the default export.
It appends a `headers()` rule for `/:path*` carrying
`Content-Security-Policy: frame-ancestors 'self' https://app.contentful.com`
(or the Contentstack region's app origin). If you already return a CSP for a
source, the directive is **merged into it** and any `X-Frame-Options` on that
source is removed; `has`, `missing` and the other rule fields pass through.
If you prefer to keep your own `headers()`, `livePreviewHeaderRules(config)`
returns the rule in Next's `Header[]` shape. Hosting dashboards and CDNs can
add `X-Frame-Options` too; check them when the preview panel is blank.

## 3. The server module

`lib/live-preview/server.ts` is the only file that reads tokens, and it reads
them **lazily, per call**: a checkout without `CONTENTFUL_SPACE_ID` (fresh
clone, CI type-check, `next build` without secrets) never throws at import
time. It exports:

| Export                                                                                                   | Purpose                                                                                      |
| -------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------- |
| `contentfulServerEnvironment()` / `contentstackServerEnvironment()`                                      | Tokens and the preview secret for the draft routes and data fetching. Never logged.          |
| `getPreviewState(searchParams?)`                                                                         | The request's preview decision, memoized per request with React `cache`.                     |
| `getLivePreviewClientConfig(locale?)`                                                                    | Token-free props for `<LivePreviewProvider>`, or `null` when the CMS environment is not set. |
| `previewTags(state, entry, options?)`                                                                    | `tag("field")` for one record; `{}` outside preview and for a `null`/`undefined` record.     |
| `contentfulGraphql(query, vars, state)` / `contentfulClient(state)`                                      | Preview-aware requests (Contentful). Omitted with `--no-fetch-helpers`.                      |
| `contentstackGraphql(...)` / `contentstackRest(...)` / `contentstackStack()` / `livePreviewQuery(state)` | Preview-aware requests (Contentstack). Omitted with `--no-fetch-helpers`.                    |

### Preview state: Contentful vs Contentstack

Contentful preview is **Next draft mode**. `draftMode()` is readable from
layouts, pages, and Server Components, so `getPreviewState()` works anywhere on
the server with no argument. Draft mode is the **only** preview signal on
Next: the package's marker cookie (`detection.cookieName`) is Nuxt's
mechanism and is ignored on Next unless you configure it explicitly. On a
CDN-cached site an unsigned cookie must never be able to flip a response into
preview rendering, because the CDN keys only on the real draft cookie and
would cache the tagged, draft-rendered HTML for everyone.

The cookie store is still read, for one thing: when the draft cookie is
present but draft mode is off — Next mints a new draft secret on every
`next dev` start and every build — the state carries
`staleDraftCookie: true` and the provider shows `<StalePreviewNotice />`
("Preview session expired — reopen the preview from Contentful"). Without it
the editor sees published content with no hint, because the panel's refresh
button reloads the page URL, not the enable URL.

Contentstack preview is the **`live_preview` hash in the URL**. Only the page
sees `searchParams`, so the page must call
`getPreviewState(await searchParams)` first; nested Server Components then call
`getPreviewState()` and receive the same decision from the per-request store.
Layouts cannot see it at all, which is why the Contentstack provider receives a
static bootstrap and activates itself from `window.location`.

## 4. Root layout

`init --write` patches the default layout. By hand:

```tsx
// app/layout.tsx
import { LivePreviewProvider } from "@/components/live-preview/LivePreviewProvider";
import { getLivePreviewClientConfig } from "@/lib/live-preview/server";

export default async function RootLayout({ children }) {
  // Contentful: await getLivePreviewClientConfig(); Contentstack: getLivePreviewClientConfig()
  // Null on an unconfigured checkout; the provider then renders children only.
  const livePreview = await getLivePreviewClientConfig();
  return (
    <html lang="en">
      <body>
        <LivePreviewProvider config={livePreview}>
          {children}
        </LivePreviewProvider>
      </body>
    </html>
  );
}
```

Outside preview the provider renders children only. In preview it starts the
SDK, provides the session to Client Components, and:

- **Contentful**: subscribes to editor `save` events and calls
  `router.refresh()`, so Server Components re-render from the Preview API.
- **Contentstack**: with `ssr: true` (default) the SDK re-fetches the current
  URL with each new hash and patches the DOM; with `ssr: false` the provider
  calls `router.replace` with the new hash on every `onEntryChange`. Either
  way it carries the session parameters across internal link clicks.

## 5. A page

### With the generated helpers

```tsx
// app/[...slug]/page.tsx
import { contentfulGraphql, getPreviewState } from "@/lib/live-preview/server";
import Hero from "@/components/Hero";

const QUERY = /* GraphQL */ `
  query Page($slug: String!, $preview: Boolean) {
    pageCollection(where: { slug: $slug }, preview: $preview, limit: 1) {
      items {
        __typename
        sys {
          id
        }
        hero {
          __typename
          sys {
            id
          }
          title
          body
        }
      }
    }
  }
`;

export default async function Page({ params, searchParams }) {
  const state = await getPreviewState(await searchParams);
  const { slug } = await params;
  const { pageCollection } = await contentfulGraphql(
    QUERY,
    { slug: slug.join("/") },
    state,
  );
  const page = pageCollection.items[0];
  return <Hero hero={page.hero} state={state} />;
}
```

`contentfulGraphql` injects `preview: state.active` into the variables and
uses the preview token when active, so one query serves both modes. In
preview the request is `cache: "no-store"`; otherwise the `init.next` options
you pass (tags, revalidate) apply.

For Contentstack, `contentstackGraphql` switches to the `graphql-preview` host
and sends the hash, preview token, and Timeline timestamp as headers;
`contentstackRest` does the same for REST; `livePreviewQuery(state)` feeds the
official delivery SDK's `stack.livePreviewQuery(...)`.

### With your own CMS client (`init --no-fetch-helpers`)

Most apps that already have a data layer — a native-fetch GraphQL client, a
full-SSR architecture that forbids `next: { revalidate, tags }`, a shared
client package — should keep it. Run `init --no-fetch-helpers` (or answer
"no" to the fetch-helpers question) and the server module stays a **preview
seam** only: state, provider config, taggers. Make the existing client
preview-aware with three rules:

1. Pass `state.active` in as the preview flag.
2. When it is true, send the Content Preview API token
   (`contentfulAccessToken(contentfulServerEnvironment(), state)` or the
   Contentstack preview headers) and fetch with `cache: "no-store"`.
3. Never cache a preview response, at any layer.

```tsx
// app/[[...slug]]/page.tsx
import { getPreviewState } from "@/lib/live-preview/server";
import { getPageByUrl } from "@/lib/content/pages"; // your client

export default async function Page({ params, searchParams }) {
  const state = await getPreviewState(await searchParams);
  const page = await getPageByUrl(urlFrom(await params), {
    preview: state.active,
  });
  return <Sections sections={page.sections} state={state} />;
}
```

GraphQL queries still declare `$preview: Boolean` and pass
`(preview: $preview)` on every collection, and still select `sys { id }` and
`__typename` at every level (SKILLS.md R2).

## 6. Components

See [SKILLS.md](../SKILLS.md) for the rules and recipes. In short:

```tsx
// Server Component
const tag = previewTags(state, entry);
<h1 {...tag("title")}>{entry.title}</h1>;

// Client Component
const live = useLiveEntry(entry);
const tag = useFieldTags(live);
<h1 {...tag("title")}>{live.title}</h1>;

// Optional nested record — no conditional hook, no extra component:
const imageTag = useFieldTags(live.image); // {} when image is null/undefined
{
  live.image?.url ? <img {...imageTag("file")} src={live.image.url} /> : null;
}
```

`useLiveEntry` subscribes to the SDK only inside an active session
(`skip` otherwise); outside one the provider never starts the SDK, and the
raw SDK hook would throw `Live updates are not initialized`. In a loop or
callback use the non-hook `fieldTagsFor(useLivePreview(), item)`.

## 7. Draft-mode routes (Contentful)

```ts
// app/api/live-preview/enable/route.ts
import { cookies, draftMode } from "next/headers";
import { createEnableDraftHandler } from "@eight25-factory/live-preview/next";
import { contentfulServerEnvironment } from "@/lib/live-preview/server";

export async function GET(request: Request): Promise<Response> {
  const handler = createEnableDraftHandler(contentfulServerEnvironment(), {
    enable: async () => (await draftMode()).enable(),
    cookies: () => cookies(),
  });
  return handler(request);
}
export const dynamic = "force-dynamic";
```

The handler is built **per request**, so the environment is read lazily. It
compares `?secret=` with `CONTENTFUL_PREVIEW_SECRET` in constant time, accepts
only a same-origin `path` (or `slug`), preserves `?locale=`, ignores unknown
parameters, and answers `307` with `Cache-Control: no-store`. The disable
route mirrors it. Set the Contentful preview URL to one of:

```
https://<site>/api/live-preview/enable?secret=<CONTENTFUL_PREVIEW_SECRET>&path=/{entry.fields.slug}&locale={locale}
https://<site>/api/live-preview/enable?secret=<CONTENTFUL_PREVIEW_SECRET>&path={entry.fields.url}&locale={locale}
```

The second form is for a field that already stores the full path with its
leading slash. `contentfulPreviewUrlTemplates(config, origin)` prints both.

### The development cookie

Production builds set the draft cookie `SameSite=None; Secure`, which a site
framed by `app.contentful.com` needs. **`next dev` sets it `SameSite=Lax`
without `Secure`** (`draft-mode-provider.js`:
`sameSite: NODE_ENV !== 'development' ? 'none' : 'lax'`), and browsers withhold
a Lax cookie from a framed page. Locally the panel then renders published
content, no tags, the SDK never connects, and the status dialog shows both
features "Disabled" — with nothing in the console.

With the `cookies` hook above, the handler re-issues the cookie in development
with `httpOnly, sameSite: "none", secure: true, path: "/"`; `localhost` counts
as a secure context, so plain `http://localhost` works. For browsers that
block third-party cookies entirely, pass
`{ draftCookie: { partitioned: true } }` as the handler's third argument.
Trade-off: a partitioned cookie is keyed to the top-level site, so it is not
sent when the editor opens the page in a new tab — the preview then shows
published content until the enable route runs again.

## 8. Caching and middleware

A page that reads `searchParams` or `draftMode()` renders dynamically, which
is what preview needs. Production pages keep whatever `revalidate`, tags, or
`generateStaticParams` they had; the generated helpers only bypass the cache
while the state is active.

**CDN caching is the part nothing in Next does for you.** A response rendered
with the draft cookie carries tags and draft content; if the CDN stores it,
every visitor gets it. In middleware (`proxy.ts` in Next 16, `middleware.ts`
before):

```ts
// proxy.ts
import { NextResponse, type NextRequest } from "next/server";
import {
  applyPreviewCacheHeaders,
  isDraftModeRequest,
} from "@eight25-factory/live-preview/next";

export default function proxy(request: NextRequest) {
  const response = NextResponse.next();
  if (isDraftModeRequest(request)) {
    // private, no-cache, no-store, must-revalidate + CDN-Cache-Control: no-store
    applyPreviewCacheHeaders(response.headers);
    return response;
  }
  // your normal cache headers here
  return response;
}

export const config = { matcher: ["/((?!api|_next|.*\\..*).*)"] };
```

`isDraftModeRequest` accepts `NextRequest` (`request.cookies.has`), the
`cookies()` store, or a plain map; `DRAFT_MODE_COOKIE_NAME` is the constant.
`?locale=` alone is **not** a preview signal and must not opt a response out
of caching. For Contentstack, requests carrying `live_preview` need the same
treatment.

## 9. Debugging without a code change

`LIVE_PREVIEW_DEBUG=1` on the server (any of `1`, `true`, `yes`) is forwarded
by `getLivePreviewClientConfig()` into the token-free client config as the
SDK's `debugMode`/`debug`, so one environment can log the SDK's decisions
without touching `live-preview.config.mjs`.

With the app running:

```sh
npx live-preview doctor http://localhost:3000
```

hits the enable route with `CONTENTFUL_PREVIEW_SECRET` from your shell,
reports the draft cookie's attributes, follows the redirect with the cookie
and counts tags, confirms the serialized provider config says `active: true`,
checks `frame-ancestors`, `X-Frame-Options` and the draft response's
`Cache-Control`, then fetches without the cookie and asserts zero tags. See
[cli.md](cli.md#doctor).

## Checklist

- [ ] `withLivePreview` wraps `next.config.*`; no `X-Frame-Options: DENY`
      anywhere, including the host
- [ ] `<LivePreviewProvider>` renders once in the root layout and accepts
      `null`
- [ ] `next build` passes with **and without** the CMS variables set
- [ ] Every page calls `getPreviewState(await searchParams)` first and passes
      `state` down
- [ ] Every CMS request uses the generated helpers, or your client receives
      `state.active` (preview host + token + `no-store` when active)
- [ ] Middleware marks draft-mode responses `no-store`
- [ ] Fields are tagged with `previewTags` / `useFieldTags`, on the element
      that renders them
- [ ] Contentful: draft-mode routes deployed with the `cookies` hook, preview
      URL set with the secret placeholder replaced only in the Contentful UI
- [ ] Contentstack: Live Preview enabled in the stack, Preview token created,
      `?builder=true` tested
- [ ] `npx live-preview doctor <url>` passes; `view-source` in production
      shows no `data-contentful-*` / `data-cslp`
