# Working with AI agents

Two files address agents. [AGENTS.md](../AGENTS.md) governs _wiring the
package into an app_; [SKILLS.md](../SKILLS.md) governs _building components_
once it is wired, and `npx live-preview install-skills` copies it to
`.claude/skills/live-preview/SKILL.md` and `.cursor/rules/live-preview.mdc`
so agents find it without being told. This page explains the reasoning, for
humans deciding how much to delegate and how to review the result.

## What agents get wrong here

Live preview has failure modes that look like success from the code alone:

### 1. Tagging that never renders

An agent adds `tag("title")` calls everywhere, the build passes, and no Edit
button ever appears — because the preview state never reached the component
(Contentstack `searchParams` not passed, provider not in the layout) and the
default policy suppresses tags. The tempting "fix" is `tags.policy: "always"`,
which leaks entry ids to production and hides the real problem. AGENTS.md
forbids that fix; SKILLS.md rule R5 says where state comes from.

### 2. Live updates that cannot work

Contentful's SDK matches editor changes to data by `sys.id` and field name.
An agent that maps entries to `{ heading, imageUrl }` props before the hook —
which is what most component libraries encourage — produces a page where
inspector mode works and typing does nothing. SKILLS.md rules R2 and R3 exist
for this, and `contentfulLiveUpdateIssues` makes it testable.

### 3. Preview data that is cached

The first preview works; the second edit shows the first edit. A `revalidate`
on the fetch, an ISR page, or a CDN rule cached the Preview API response. The
generated helpers send `no-store` while previewing; the gates in AGENTS.md
ask about the CDN because the package cannot see it.

### 4. A secret in the browser

The Contentful and Contentstack browser SDKs are initialized with public ids
only. Agents that have seen `NEXT_PUBLIC_*_TOKEN` patterns elsewhere reach for
them here. The package never puts a token in any client-facing shape, every
test asserts that, and AGENTS.md gate 7 says why.

### 5. Blank panel blamed on code

`X-Frame-Options: DENY` set in a hosting dashboard blanks the preview panel
with no application error. The verification protocol (SKILLS.md Skill 4)
starts with the frame for this reason.

## The gates

AGENTS.md front-loads eight gates. Two matter most.

**Gate 0** asks whether preview is already wired. Two SDK initializations on
one page break both, and an existing draft-mode route with a different secret
scheme should be migrated, not duplicated. The instruction is to stop and ask.

**Gate 3** asks where data is fetched. Preview only works if _every_ request
for a previewed page follows the state; an application with three ad-hoc
fetch paths needs a single entry point before it needs this package.

## Asking, not guessing

Agents are instructed to:

- Never ask for a secret value; ask for the variable **name** to be set and
  confirm with `check-env`.
- Never infer the CMS from a network probe.
- Ask one question at a time in the [setup order](setup-questions.md),
  skipping anything the environment answers. `nextSetupQuestion` exposes the
  flow so an agent can ask through its own interface.
- Report what was verified in the editor and what could not be.

## Reviewing agent output

1. Is the provider rendered once, in the root layout / plugins, and nowhere
   else is an SDK initialized?
2. Does every page call `getPreviewState(await searchParams)` (Next) or
   `previewStateFor(event)` (Nuxt) and pass the state down?
3. Do the fetches use the generated helpers, or reproduce preview host +
   token + `no-store`?
4. Are tags on the elements that render the fields, from `previewTags` /
   `useFieldTags`, with no hand-written attributes?
5. Do the queries select identity (`sys { id } __typename` /
   `system { uid content_type_uid locale }`) at every level, and do components
   receive raw records?
6. Is `tags.policy` still `preview-only`?
7. Is there any `NEXT_PUBLIC_` or `runtimeConfig.public` token? There must not
   be.
8. Did the agent run Skill 4 and say what it saw?

Then verify with a request:

```sh
curl -sI https://staging.example.com/about | grep -iE 'content-security-policy|x-frame-options'
# content-security-policy: frame-ancestors 'self' https://app.contentful.com
# (no x-frame-options line)
```

and open an entry in the CMS: panel renders, hover outlines, typing updates.

## Repository conventions

An agent working on the package itself must know that source lives twice
(`src/` and `packages/*/src/`), regenerated with `node scripts/sync-mirror.mjs`
and enforced by `test/source-mirror.test.ts`; that `SKILLS.md` is the single
source for the skill and `skills/` is generated at build; and that
`npm run validate` covers formatting, types, and tests.
