# Default configuration

Every option `live-preview.config.mjs` accepts, its default, and what it
controls. Unknown keys are errors: a typo fails at load time rather than being
ignored.

```js
export const livePreviewOptions = {
  provider: "contentful", // required: "contentful" | "contentstack"
  framework: "neutral", // "next" | "nuxt" | "neutral"

  contentful: {
    locale: "en-US",
    region: "default", // "default" | "eu"
    enableInspectorMode: true,
    enableLiveUpdates: true,
    debugMode: false,
    targetOrigin: ["https://app.contentful.com"], // derived from region
    includeSpaceAndEnvironment: false,
    draftMode: {
      enablePath: "/api/live-preview/enable",
      disablePath: "/api/live-preview/disable",
    },
  },

  contentstack: {
    region: "us", // us | na | eu | au | azure-na | azure-eu | gcp-na | gcp-eu
    mode: "auto", // "auto" | "preview" | "builder"
    ssr: true,
    editButton: {
      enable: true,
      position: "top",
      includeByQueryParameter: true,
      exclude: [], // "insideLivePreviewPortal" | "outsideLivePreviewPortal"
    },
    cleanCslpOnProduction: true,
    debug: false,
    defaultLocale: "en-us",
    lowercaseLocale: true,
  },

  tags: {
    policy: "preview-only", // "preview-only" | "always" | "never"
  },

  security: {
    frameAncestors: [], // extra origins, appended to the editor origin
    allowSelf: true,
  },

  detection: {
    cookieName: "e25_live_preview",
    // queryParameter: "preview",  // off by default
  },
};
```

Only the section for the chosen provider may be present; the other is an
error.

## `provider` (required)

Selects the adapter, the tag format, the editor origin, and which section
below applies.

## `framework`

Informational; recorded so tooling and agents know which recipes apply.
Default `neutral`.

## `contentful`

| Option                       | Default                     | Controls                                                            |
| ---------------------------- | --------------------------- | ------------------------------------------------------------------- |
| `locale`                     | `en-US`                     | SDK locale; default tag locale when the entry has none              |
| `region`                     | `default`                   | Every host: app, CDN, preview, GraphQL                              |
| `enableInspectorMode`        | `true`                      | Passed to the SDK                                                   |
| `enableLiveUpdates`          | `true`                      | Passed to the SDK                                                   |
| `debugMode`                  | `false`                     | Passed to the SDK; logs its decisions in the console                |
| `targetOrigin`               | region's app origin         | Origins the SDK accepts editor messages from                        |
| `includeSpaceAndEnvironment` | `false`                     | Emit `data-contentful-space` / `-environment` on tags when supplied |
| `draftMode.enablePath`       | `/api/live-preview/enable`  | Route the Contentful preview URL points to                          |
| `draftMode.disablePath`      | `/api/live-preview/disable` | Route that ends the session                                         |

## `contentstack`

| Option                               | Default | Controls                                                                             |
| ------------------------------------ | ------- | ------------------------------------------------------------------------------------ |
| `region`                             | `us`    | Every host: app, CDN, REST preview, GraphQL, GraphQL preview                         |
| `mode`                               | `auto`  | SDK `mode`; `auto` resolves per request from `?builder=true`                         |
| `ssr`                                | `true`  | SDK `ssr`; who applies updates (SDK DOM patch vs application refetch)                |
| `editButton.enable`                  | `true`  | Show the Edit button on hover                                                        |
| `editButton.position`                | `top`   | Where the button sits                                                                |
| `editButton.includeByQueryParameter` | `true`  | Honour `?cslp-buttons=`                                                              |
| `editButton.exclude`                 | `[]`    | Hide inside or outside the preview portal                                            |
| `cleanCslpOnProduction`              | `true`  | SDK strips `data-cslp` when disabled (belt and braces; tags are policy-gated anyway) |
| `debug`                              | `false` | SDK console logging                                                                  |
| `defaultLocale`                      | `en-us` | Tag locale when the entry has none                                                   |
| `lowercaseLocale`                    | `true`  | Lowercase the locale segment of `data-cslp`, as `@contentstack/utils` does           |

## `tags.policy`

| Value          | Behaviour                                                                           |
| -------------- | ----------------------------------------------------------------------------------- |
| `preview-only` | Tags only while a preview session is active. Production HTML is clean. **Default.** |
| `always`       | Tags on every render. Harmless, noisier markup, leaks entry ids to the public.      |
| `never`        | No tags; inspector mode and click-to-edit do not work.                              |

## `security`

`frameAncestors` are **extra** origins; the editor origin for the region is
always included. `allowSelf` adds `'self'`. The resolved list is
`config.security.frameAncestors`, rendered by `frameAncestorsDirective`.

## `detection`

| Option           | Default            | Controls                                                                                                                              |
| ---------------- | ------------------ | ------------------------------------------------------------------------------------------------------------------------------------- |
| `cookieName`     | `e25_live_preview` | Session marker on frameworks without draft mode (Nuxt). Not a secret; not `httpOnly`.                                                 |
| `queryParameter` | unset              | A truthy `?<name>=` marks preview. Only behind authentication; a public URL parameter must never be the only gate in front of drafts. |

## Derived values

| Value                     | Derived from                                                                                  |
| ------------------------- | --------------------------------------------------------------------------------------------- |
| `editor.appOrigin`        | provider + region                                                                             |
| `security.frameAncestors` | `'self'` + `editor.appOrigin` + `security.frameAncestors`                                     |
| `contentful.targetOrigin` | region, unless set                                                                            |
| Tag locale                | field option → entry locale → `?locale=` → `contentful.locale` / `contentstack.defaultLocale` |
| Contentstack SDK `mode`   | `contentstack.mode`, with `auto` → `?builder=true`                                            |
| Contentstack SDK `enable` | the preview state's `active`                                                                  |
