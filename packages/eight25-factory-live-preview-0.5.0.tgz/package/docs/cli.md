# CLI

```
npx live-preview <command> [options]
```

Every command is also a function in `@eight25-factory/live-preview/cli`, so an
agent or a script can call the same logic without spawning a process.

## `init`

Asks the [setup questions](setup-questions.md), prints the plan, and with
`--write` creates the files.

```sh
npx live-preview init              # print the files and the next steps
npx live-preview init --write      # create them (existing files are kept)
npx live-preview init --write --force
npx live-preview init --yes --write --provider contentstack --region eu
```

| Option                                | Effect                                                               |
| ------------------------------------- | -------------------------------------------------------------------- |
| `--framework next\|nuxt`              | Skip the framework question                                          |
| `--provider contentful\|contentstack` | Skip the provider question                                           |
| `--locale <code>`                     | `en-US` (Contentful) / `en-us` (Contentstack)                        |
| `--region <code>`                     | Contentful `default\|eu`; Contentstack `us\|eu\|au\|azure-na\|…`     |
| `--src-dir <dir>`                     | `src` when the app lives under `src/`; detected when omitted         |
| `--yes`                               | Accept every default without asking                                  |
| `--write`                             | Create the files; without it the plan is printed                     |
| `--force`                             | Overwrite files that already exist                                   |
| `--no-install`                        | With `--write`, skip installing the CMS SDK and this package         |
| `--no-patch`                          | With `--write`, leave `next.config.*` and `app/layout.tsx` untouched |
| `--no-fetch-helpers`                  | The app has its own CMS client: omit `contentfulGraphql` & co.       |
| `--dir <path>`                        | Project directory, default the current one                           |

The plan lists every file and the manual steps that remain
(`next.config.mjs` / `nuxt.config.ts`, root layout, CMS preview URL,
verification). It also reports which credential **names** are set, never
their values. When the skill question is answered yes, `--write` also runs
`install-skills` for `claude,agents`.

With `--write`, `init` also adds `@eight25-factory/live-preview` and the
provider's SDK (`@contentful/live-preview` or
`@contentstack/live-preview-utils`) when `package.json` does not list them.
It runs the project's package manager, chosen from the lockfile
(`bun.lockb`/`bun.lock`, `pnpm-lock.yaml`, `yarn.lock`,
`package-lock.json`), then the `packageManager` field, then npm. Without a
`package.json` it prints the command instead. A failed install is reported
with the command to retry; the wiring files are still written. `--no-install`
skips this step. The same logic is exported as `installDependencies`,
`detectPackageManager`, `missingDependencies` and `installCommand`.

With `--write` on a Next project, `init` also patches `next.config.ts`
(`.mjs`/`.js`) and `app/layout.tsx` when they have the create-next-app
shape: the config's default export is wrapped in `withLivePreview`, and the
layout becomes async, awaits `getLivePreviewClientConfig()` and renders
`<LivePreviewProvider>` around `{children}`. Files that do not match are left
alone and reported as `manual` with the snippet to apply; `--no-patch` skips
the step. Exported as `patchNextConfigSource` / `patchRootLayoutSource`
(pure) and `patchNextProject`.

`--no-fetch-helpers` (or the matching setup question) is for an app that
already has a Contentful/Contentstack client. The generated
`lib/live-preview/server.ts` then contains only the preview seam — state,
provider config, taggers — and the next steps say how to make the existing
client preview-aware: pass `state.active` in as the preview flag, use the
preview token and `cache: "no-store"` when it is true.

## `check-env`

```sh
npx live-preview check-env
npx live-preview check-env --provider contentful
```

Prints `set` / `unset` for every variable the adapter reads, marking required
and secret ones. Values are never read into the output.

## `install-skills`

```sh
npx live-preview install-skills                       # claude + agents
npx live-preview install-skills --target claude,cursor,agents
npx live-preview install-skills --force
```

| Target   | Writes                                                                                                                                |
| -------- | ------------------------------------------------------------------------------------------------------------------------------------- |
| `claude` | `.claude/skills/live-preview/SKILL.md` — frontmatter + the full `SKILLS.md`                                                           |
| `cursor` | `.cursor/rules/live-preview.mdc`                                                                                                      |
| `agents` | Appends a pointer section to `AGENTS.md` (or `CLAUDE.md` when only that exists); creates `AGENTS.md` when neither exists. Idempotent. |

Existing files are kept unless `--force`. The body comes from the installed
package's `SKILLS.md`; `LIVE_PREVIEW_PACKAGE_ROOT` overrides where it is read
from, for vendored installs.

## `create-component`

```sh
npx live-preview create-component Hero
npx live-preview create-component Hero --fields title,body,image
npx live-preview create-component Hero --client            # Next Client Component
npx live-preview create-component Hero --framework vue     # Nuxt SFC
```

Writes a component with every listed field rendered and tagged, with the
identity fields the provider needs in its prop type, and comments pointing at
the rules. Framework and provider are detected (config files, environment
names) or given with `--framework react|vue` and `--provider`.

## `doctor`

```sh
npx live-preview doctor http://localhost:3000
npx live-preview doctor https://preview.example.com --path /about --secret-env PREVIEW_SECRET
npx live-preview doctor http://localhost:3000 --provider contentstack
```

Against a **running** app, in order:

1. `GET <enable-path>?secret=…&path=<path>` with the secret read from
   `--secret-env` (default `CONTENTFUL_PREVIEW_SECRET`) in your shell. Reports
   the status and the `Set-Cookie` attributes of `__prerender_bypass`;
   `SameSite=Lax` or a missing `Secure` is a failure ("will not work inside
   the Contentful iframe" — the `next dev` default without the generated
   route's cookie fix).
2. `GET <path>` with that cookie: counts `data-contentful-entry-id`
   (`data-cslp`) tags, looks for the serialized provider config's
   `active: true`, checks `Content-Security-Policy: frame-ancestors`, the
   absence of `X-Frame-Options`, and that `Cache-Control` (and
   `CDN-Cache-Control` when present) say `no-store`.
3. `GET <path>` without the cookie: asserts zero tags.

| Option                   | Default                     |
| ------------------------ | --------------------------- |
| `--provider`             | `contentful`                |
| `--secret-env <NAME>`    | `CONTENTFUL_PREVIEW_SECRET` |
| `--path </page>`         | `/`                         |
| `--enable-path </route>` | `/api/live-preview/enable`  |

Prints one line per check (`OK`, `WARN`, `FAIL`, `SKIP`) and exits 1 on any
failure. The secret value is never printed; without it the draft checks are
skipped and only the production render is checked. For Contentstack the
cookie steps do not apply; framing, cache headers and the production render
are checked. Exported as `runDoctor(options, fetch?)` with the individual
assessors (`assessDraftCookie`, `assessFrameHeaders`, `assessCacheHeaders`,
`countTags`, `serializedActiveFlag`).

## `print-skill`

```sh
npx live-preview print-skill | pbcopy
```

Prints `SKILLS.md` to stdout, for pasting into an agent's context.

## Environment variables that answer questions

`LIVE_PREVIEW_FRAMEWORK`, `LIVE_PREVIEW_PROVIDER`, `LIVE_PREVIEW_LOCALE`,
`CONTENTFUL_REGION`, `CONTENTSTACK_REGION`, `LIVE_PREVIEW_CONTENTSTACK_MODE`,
`LIVE_PREVIEW_CONTENTSTACK_SSR`, `LIVE_PREVIEW_FETCH_HELPERS`,
`LIVE_PREVIEW_INSTALL_SKILLS`. See [setup questions](setup-questions.md).
At runtime, `LIVE_PREVIEW_DEBUG=1` turns the CMS SDK's console logging on for
that deployment (forwarded by `getLivePreviewClientConfig()`).

## Programmatic use

```ts
import {
  nextSetupQuestion,
  applyAnswer,
  resolveSetup,
  buildSetupPlan,
  writeFiles,
  installDependencies,
  installSkills,
} from "@eight25-factory/live-preview/cli";

let answers = {};
for (;;) {
  const question = nextSetupQuestion(answers, {
    environment: process.env,
    detectedFramework: "next",
  });
  if (!question) break;
  answers = applyAnswer(answers, question, await askTheUser(question));
}
const plan = buildSetupPlan(
  resolveSetup(answers, { environment: process.env }, "src/"),
);
await writeFiles(plan.files, ".");
await installDependencies(plan.config.provider, ".");
await installSkills(["claude", "agents"], ".");
```
