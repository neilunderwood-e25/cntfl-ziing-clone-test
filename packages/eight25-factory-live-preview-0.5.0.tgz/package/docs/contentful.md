# Contentful

Live preview in Contentful is three cooperating features, and this package
wires all three:

| Feature            | What it is                                                         | What makes it work                                           |
| ------------------ | ------------------------------------------------------------------ | ------------------------------------------------------------ |
| **Live preview**   | The editor frames your site and shows draft content                | Draft mode + Content Preview API + `frame-ancestors`         |
| **Inspector mode** | Hovering a field on the page outlines it and offers an Edit button | `data-contentful-entry-id` / `-field-id` / `-locale` tags    |
| **Live updates**   | Typing in the editor updates the page without saving               | `@contentful/live-preview` SDK + untransformed data with ids |

## Credentials

```dotenv
# .env.local — ignored by git. Set the same names in hosted build environments.
CONTENTFUL_SPACE_ID=
CONTENTFUL_ENVIRONMENT=master
CONTENTFUL_PREVIEW_TOKEN=          # Content Preview API token
CONTENTFUL_DELIVERY_TOKEN=         # Content Delivery API token (CONTENTFUL_ACCESS_TOKEN also accepted)
CONTENTFUL_PREVIEW_SECRET=         # long random value; also pasted into the Contentful preview URL
CONTENTFUL_REGION=default          # or eu
```

| Variable                    | Required | Secret | Notes                                                              |
| --------------------------- | -------- | ------ | ------------------------------------------------------------------ |
| `CONTENTFUL_SPACE_ID`       | yes      | no     |                                                                    |
| `CONTENTFUL_ENVIRONMENT`    | no       | no     | Defaults to `master`                                               |
| `CONTENTFUL_PREVIEW_TOKEN`  | yes      | yes    | Alias `CONTENTFUL_PREVIEW_ACCESS_TOKEN`                            |
| `CONTENTFUL_DELIVERY_TOKEN` | no       | yes    | Alias `CONTENTFUL_ACCESS_TOKEN`; preview token is used when absent |
| `CONTENTFUL_PREVIEW_SECRET` | yes      | yes    | Compared in constant time by the enable route                      |
| `CONTENTFUL_REGION`         | no       | no     | `eu` switches every host to `*.eu.contentful.com`                  |

A Preview token reads drafts; a Delivery token reads published content. Never
use a Management token here. `npx live-preview check-env --provider contentful`
reports presence only.

## Preview mode: draft mode and the preview URL

Contentful has no marker in the URL that says "this is a preview request".
Instead the editor opens the **preview URL** you configure, that URL turns
preview on for the browser session, and redirects to the page.

Settings → Content preview → Add content preview → for each content type:

```
https://<site>/api/live-preview/enable?secret=<CONTENTFUL_PREVIEW_SECRET>&path=/{entry.fields.slug}&locale={locale}
https://<site>/api/live-preview/enable?secret=<CONTENTFUL_PREVIEW_SECRET>&path={entry.fields.url}&locale={locale}
```

`{entry.fields.slug}` and `{locale}` are Contentful's own placeholders. The
first form is for a `slug` field (the route prepends the slash); the second
for a field that stores the full public path (`/about/team`). `slug=` and
`path=` are both accepted, `?locale=` is carried through to the page, and
unknown parameters such as `env=` are ignored. Add a prefix such as
`&path=/blog/{entry.fields.slug}` per content type when needed.
`contentfulPreviewUrlTemplate(config, origin, options)` prints one string;
`contentfulPreviewUrlTemplates(config, origin)` prints both. `init` prints
them too, and they sit as comments in `.env.live-preview.example`.

The enable route (generated) validates the secret, turns on Next draft mode or
sets the Nuxt session cookie, and redirects to `path`. From then on:

- `resolvePreviewState` reports `active: true, source: "draft-mode"` (Next) or
  `"cookie"` (Nuxt); on Next the marker cookie is ignored unless configured
- `contentfulClientOptions` / `contentfulRequestHeaders` switch to
  `preview.contentful.com` and the preview token
- the GraphQL helper passes `preview: true`
- tags are emitted; the SDK starts

The disable route ends the session. Both live at `contentful.draftMode.enablePath` /
`disablePath` (defaults `/api/live-preview/enable` and `/disable`).

## The Preview API

REST: same paths as the Delivery API on `preview.contentful.com`, preview
token as `Authorization: Bearer`. GraphQL: **same endpoint**
(`graphql.contentful.com`); the preview token makes it return drafts, and
queries take `preview: Boolean` arguments. Use `$preview` in every collection
or entry query so one document serves both modes.

Never cache a Preview API response. The generated helpers send
`cache: "no-store"` while the state is active.

## Inspector mode

Inspector mode reads attributes from the DOM:

```html
<h1
  data-contentful-entry-id="6KntaYXaHSyIw8M6eo26OK"
  data-contentful-field-id="title"
  data-contentful-locale="en-US"
></h1>
```

`tagsFor(config, state, entry)("title")` builds them. Rules:

- The **field id** is the field's API id, not its name. GraphQL exposes a
  reference list `items` as `itemsCollection`; the tag must say `items`
  (`contentfulFieldId("itemsCollection")`).
- **Assets** are their own records: `tagsFor(state, asset)("file")` on the
  `<img>`. The tagger recognises an asset by `sys.type === "Asset"` or
  `__typename: "Asset"` and emits `data-contentful-asset-id`.
- **Locale** is required for the Edit button to appear. The tagger fills it
  from the entry's `sys.locale`, then `?locale=`, then `contentful.locale`.
- **Space and environment** attributes are only needed when the SDK is not
  initialized with them; set `contentful.includeSpaceAndEnvironment: true`
  and pass them to the tagger if a page mixes spaces.

Tags are emitted only while previewing under the default policy, so production
HTML is clean.

## Live updates

The SDK (`@contentful/live-preview`) receives the edited entry from the editor
and merges it into the data your component subscribed with. It can only do
that when:

1. every entry and asset in the data carries `sys.id`;
2. with GraphQL, every entry also carries `__typename`;
3. the data is **untransformed** — the shape the API returned.

`contentfulLiveUpdateIssues(data, "graphql" | "rest")` lists violations; use
it in a test for each page query. `assertContentfulLiveUpdateShape` throws.

Delivery in the two frameworks:

- **Next Server Components** cannot subscribe. The generated provider
  subscribes to editor **save** events and calls `router.refresh()`, so the
  route re-renders from the Preview API. Contentful autosaves every few
  seconds, so this is "near-live". For keystroke-level updates, make the leaf
  a Client Component and use `useLiveEntry(entry, { query })`, which wraps
  `useContentfulLiveUpdates`.
- **Nuxt**: `useLiveEntry(entryRef)` wraps `ContentfulLivePreview.subscribe`
  for the entry the component fetched; the client plugin also refreshes data
  on save.

Only Client Components can use `@contentful/live-preview/react`; the generated
provider is the one place the SDK is initialized.

## Locales

The SDK is initialized with one locale (`contentful.locale`, default `en-US`).
Multi-locale sites pass the page locale to `getLivePreviewClientConfig(locale)`
(Next) / `clientStateFor(event, locale)` (Nuxt); tags follow the entry's
`sys.locale` when present. An editor previewing another locale should open the
preview URL with `&locale={locale}`.

## Regions

`contentful.region: "eu"` (or `CONTENTFUL_REGION=eu`) switches every host:
`app.eu.contentful.com` (framing and `targetOrigin`), `cdn.eu.contentful.com`,
`preview.eu.contentful.com`, `graphql.eu.contentful.com`.

## Failure modes

| Symptom                                   | Cause                                                                                    |
| ----------------------------------------- | ---------------------------------------------------------------------------------------- |
| Preview panel blank                       | `X-Frame-Options` or CSP without `https://app.contentful.com`, at app, host, or CDN      |
| `401` from the enable route               | Secret mismatch; `CONTENTFUL_PREVIEW_SECRET` not set where the route runs                |
| `400` from the enable route               | `path` is not a same-origin path (absolute URL, `//`, `..`)                              |
| Published content shown in preview        | Draft mode not on (cookie dropped: needs HTTPS in the frame), or fetch not preview-aware |
| Edit button appears on some fields only   | Missing tag or wrong field id on those elements; missing locale attribute                |
| Panel says "Live updates: Disabled"       | `sys.id` / `__typename` missing, or data transformed before the hook                     |
| Updates only after a few seconds          | Server Component path (refresh on save); expected. Use a Client Component for keystrokes |
| Everything works locally, not on the host | Host adds `X-Frame-Options`, or edge cache serves preview requests                       |

Errors from the environment reader name the variable, never a value.
