# Setup questions

The normative list of questions asked when installing the package.
`npx live-preview init` asks exactly these, in this order, and
`nextSetupQuestion` exposes the same flow programmatically so an AI agent can
ask them through its own user-question mechanism.

**A question is skipped whenever the environment already answers it.** Each
entry names the variable or file that answers it. Run
`npx live-preview check-env` first to see which credential names are set; it
reports presence only and never prints a value.

## The questions

### 1. Which framework is this application?

Choices `next`, `nuxt`. Default `next`.
**Skipped when** a `next.config.*` or `nuxt.config.*` file is present, or
`LIVE_PREVIEW_FRAMEWORK` is set.

### 2. Which CMS does this application read from?

Choices `contentful`, `contentstack`. Default `contentful`.
**Skipped when** exactly one provider has all of its required variables set,
or `LIVE_PREVIEW_PROVIDER` is set. Asked, with a reason, when none or both do.

| Provider       | Required variable names                                                                                         |
| -------------- | --------------------------------------------------------------------------------------------------------------- |
| `contentful`   | `CONTENTFUL_SPACE_ID`, `CONTENTFUL_PREVIEW_TOKEN`, `CONTENTFUL_PREVIEW_SECRET`                                  |
| `contentstack` | `CONTENTSTACK_API_KEY`, `CONTENTSTACK_ENVIRONMENT`, `CONTENTSTACK_DELIVERY_TOKEN`, `CONTENTSTACK_PREVIEW_TOKEN` |

### 3. Which locale?

Contentful: the locale the Live Preview SDK starts with. Default `en-US`.
Contentstack: the locale written into `data-cslp` when an entry states none.
Default `en-us`.
**Answered by** `LIVE_PREVIEW_LOCALE`.

### 4. Which region?

Contentful: `default`, `eu`. Default `default`. **Answered by** `CONTENTFUL_REGION`.
Contentstack: `us`, `na`, `eu`, `au`, `azure-na`, `azure-eu`, `gcp-na`,
`gcp-eu`. Default `us`. **Answered by** `CONTENTSTACK_REGION`.

The region sets the editor origin allowed to frame the site and every API
host.

### 5. Which editing surface should Start Editing open? _(Contentstack only)_

Choices `auto`, `preview`, `builder`. Default `auto`, which opens the Visual
Builder when the URL carries `?builder=true` and Live Preview otherwise.
**Answered by** `LIVE_PREVIEW_CONTENTSTACK_MODE`.

### 6. How should the page update while editing? _(Contentstack only)_

Choices `true` (SSR: the SDK re-fetches the URL with the new hash and patches
the DOM), `false` (CSR: the app refetches in `onEntryChange`). Default `true`.
**Answered by** `LIVE_PREVIEW_CONTENTSTACK_SSR`.

### 7. Generate the preview-aware fetch helpers?

Choices `true`, `false`. Default `true`. `true` writes `contentfulGraphql` /
`contentfulClient` (or `contentstackGraphql` / `contentstackRest` /
`contentstackStack`) into `lib/live-preview/server.ts`. Answer `false` when
the app already has its own CMS client: the server module then holds only
the preview seam (state, provider config, taggers) and the next steps say
how to make the existing client preview-aware.
**Answered by** `LIVE_PREVIEW_FETCH_HELPERS`, or the `--no-fetch-helpers`
flag.

### 8. Install the AI skill file?

Choices `true`, `false`. Default `true`. Writes
`.claude/skills/live-preview/SKILL.md` and appends a pointer section to
`AGENTS.md` (or `CLAUDE.md` when only that exists).
**Answered by** `LIVE_PREVIEW_INSTALL_SKILLS`.

## Not asked

- **Source directory.** Detected from `src/app`, `src/pages`, or
  `src/components`; override with `--src-dir`.
- **Next config file.** `next.config.ts`, `.mjs` or `.js` is detected; the
  printed snippet and the automatic patch follow it.
- **Draft-mode route paths.** `/api/live-preview/enable` and `/disable`;
  change them in `live-preview.config.mjs` afterwards.
- **Tag policy.** `preview-only`; change it in the configuration only with a
  reason.
- **Secrets.** Never. The CLI asks you to set the variable **name** and
  confirms presence.

## Running non-interactively

```sh
LIVE_PREVIEW_PROVIDER=contentstack CONTENTSTACK_REGION=eu npx live-preview init --yes --write
```

`--yes` accepts the default for anything still unanswered. Flags
(`--framework`, `--provider`, `--locale`, `--region`) override both the
environment and the questions.
