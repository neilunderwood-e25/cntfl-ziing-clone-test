# Local folder installation

The default installation is from npm:

```sh
npm install @eight25-factory/live-preview
```

Use a vendored install only when the application must carry the package in
its own repository — an air-gapped build, a pinned audit artifact, or a
monorepo that does not reach the registry.

## Getting the artifact

Every release attaches the exact tarball that was published to npm to the
GitHub Release `v<version>`:

```sh
gh release download v0.5.0 \
  --repo 825media/eight25-factory-live-preview-main \
  --pattern 'eight25-factory-live-preview-*.tgz'
# eight25-factory-live-preview-0.5.0.tgz
```

Or pack it yourself from a checkout of this repository:

```sh
npm ci
npm run validate
npm pack
# eight25-factory-live-preview-0.5.0.tgz
```

`files` limits the tarball to `dist/`, `README.md`, `AGENTS.md`, `SKILLS.md`,
`skills/`, and `docs/`, and `prepack` runs `scripts/check-package.mjs`, which
fails the pack if anything else would be included. The workspace packages
under `packages/` are all `private: true` and are not included.

Do **not** add the repository itself as a dependency
(`"@eight25-factory/live-preview": "github:825media/..."` or a git URL). The
repository carries TypeScript source and no `dist/`, so nothing would resolve.

## Installing the tarball

```sh
mkdir -p packages/live-preview
tar -xzf eight25-factory-live-preview-0.5.0.tgz --strip-components=1 -C packages/live-preview
npm install ./packages/live-preview
```

`package.json` then records:

```json
{
  "dependencies": {
    "@eight25-factory/live-preview": "file:packages/live-preview"
  }
}
```

Every import and subpath works exactly as it does from npm, because the
`exports` map is the same. The CLI finds `SKILLS.md` by walking up from
`dist/cli.js` to the package's own `package.json`; set
`LIVE_PREVIEW_PACKAGE_ROOT=packages/live-preview` if the folder is renamed.

## What the folder must contain

```
packages/live-preview/
  package.json
  dist/
  README.md
  AGENTS.md
  SKILLS.md
  skills/
  docs/
```

**It must be the packed artifact, not this repository's TypeScript source.** A
folder containing `src/` and no `dist/` will not resolve.

## Verifying

```sh
node -e "import('@eight25-factory/live-preview').then((m) => console.log(typeof m.tagsFor))"
# function
npx live-preview check-env
```

## Updating

Re-pack, replace the folder, and reinstall. A `file:` dependency is resolved
at install time, so nothing updates until `npm install` runs again. Commit the
folder and the lockfile together. Re-run `npx live-preview install-skills
--force` so the project's skill file matches the new version.

Prefer npm unless one of the constraints above genuinely applies, and never
switch an application between the two without saying so.
