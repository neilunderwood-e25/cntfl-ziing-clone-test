# API reference

Every public export, by entry point. Types are listed where they shape how a
function is called; see the `.d.ts` files for the complete signatures.

## `@eight25-factory/live-preview` (core)

Pure functions. No network, filesystem, or framework access.

### Configuration

| Export                                                                                                          | Description                                                                   |
| --------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------- |
| `parseLivePreviewConfig(input)`                                                                                 | Validates `LivePreviewConfigInput` → `LivePreviewConfig`. Unknown keys throw. |
| `livePreviewConfigSchema`                                                                                       | `{ parse, safeParse }` around the same parser.                                |
| `LivePreviewValidationError`                                                                                    | Thrown by every validator; `issues: string[]` names paths.                    |
| `DEFAULT_CONTENTFUL_OPTIONS`, `DEFAULT_CONTENTSTACK_OPTIONS`, `DEFAULT_TAGS_CONFIG`, `DEFAULT_DETECTION_CONFIG` | Every default.                                                                |
| `contentfulOptionsOf(config)`, `contentstackOptionsOf(config)`                                                  | The provider section; throws on the wrong provider.                           |
| `CONTENTFUL_REGIONS`, `CONTENTSTACK_REGIONS`, `*_REGION_CODES`                                                  | Region → host tables.                                                         |

### Preview state

| Export                                                        | Description                                                                                                                                                                                                                                                                                     |
| ------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `resolvePreviewState(config, signals?)`                       | `{ searchParams?, cookies?, draftModeEnabled?, staleDraftCookie? }` → `PreviewState { active, source, builder, staleDraftCookie, locale?, contentstack? }`. On `framework: "next"` the marker cookie counts only when `detection.cookieName` was configured (`detection.cookieNameConfigured`). |
| `livePreviewDebugEnabled(env)`, `LIVE_PREVIEW_DEBUG_VARIABLE` | `LIVE_PREVIEW_DEBUG=1\|true\|yes` → SDK debug logging for one deployment.                                                                                                                                                                                                                       |
| `inactivePreviewState(config)`                                | A production state.                                                                                                                                                                                                                                                                             |
| `contentstackPreviewQueryFromSearchParams(params)`            | `{ hash?, contentTypeUid?, entryUid?, previewTimestamp?, releaseId?, builder }`.                                                                                                                                                                                                                |
| `readSearchParams(input)`, `readCookie(cookies, name)`        | Normalizers for the shapes frameworks hand over.                                                                                                                                                                                                                                                |
| `previewSearchParams(config, state, current?)`                | The parameters to carry across internal navigation.                                                                                                                                                                                                                                             |
| `withPreviewParams(href, config, state, current?)`            | Appends them to a same-site URL; external URLs untouched.                                                                                                                                                                                                                                       |

### Tagging

| Export                                                                                                                                                                                   | Description                                                                                                                                             |
| ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `tagsFor(config, state, entry, options?)`                                                                                                                                                | `EntryTagger`: `tag(fieldId, { locale? })` → attributes or `{}`. A `null`/`undefined` entry yields a disabled tagger; an entry without identity throws. |
| `inactiveEntryTagger(identity?)`                                                                                                                                                         | A tagger that emits nothing (`enabled: false`).                                                                                                         |
| `clientTagsFor(client, entry, options?)`                                                                                                                                                 | Same from a serialized `LivePreviewClientBase` (browser).                                                                                               |
| `fieldTagAttributes(config, state, input)`                                                                                                                                               | One tag from explicit `{ id, fieldId, contentTypeId?, locale?, asset? }`.                                                                               |
| `tagContextOf(config, state)`, `tagContextFromClient(client)`, `fieldTagAttributesIn(context, input)`, `createEntryTagger(context, identity)`, `entryTaggerIn(context, entry, options?)` | The lower-level pieces the above compose.                                                                                                               |
| `entryIdentityOf(provider, entry)`                                                                                                                                                       | `{ id, contentTypeId?, locale?, asset? }` or `undefined`.                                                                                               |
| `contentfulTagAttributes(input)`                                                                                                                                                         | Raw `data-contentful-*` builder (no policy).                                                                                                            |
| `contentstackTagAttributes(input, options?)`                                                                                                                                             | Raw `data-cslp` builder (no policy).                                                                                                                    |
| `tagAttributesToString(attributes)`                                                                                                                                                      | Escaped attribute string for raw HTML.                                                                                                                  |
| `CONTENTFUL_TAG_ATTRIBUTES`, `CONTENTSTACK_TAG_ATTRIBUTE`, `CONTENTSTACK_EMPTY_BLOCK_PARENT_CLASS`                                                                                       | Attribute names and the builder marker class.                                                                                                           |

### Security, cookie, client bootstrap

| Export                                                     | Description                                                                |
| ---------------------------------------------------------- | -------------------------------------------------------------------------- |
| `frameAncestorsDirective(config)`                          | `frame-ancestors 'self' <editor origin> …`.                                |
| `mergeContentSecurityPolicy(existing, directive)`          | Replaces or adds `frame-ancestors` in a CSP string.                        |
| `livePreviewSecurityHeaders(config, existingCsp?)`         | `{ "Content-Security-Policy": … }`.                                        |
| `CONFLICTING_FRAME_HEADERS`                                | `["X-Frame-Options"]`.                                                     |
| `previewSessionCookie(config, "set" \| "clear", options?)` | `{ name, value, attributes, header }`; `SameSite=None; Secure` by default. |
| `livePreviewClientBase(config, state)`                     | The token-free, serializable base the framework client configs extend.     |
| `hydrateContentstackClient(client, search)`                | Finishes a Contentstack bootstrap from `window.location.search`.           |

## `@eight25-factory/live-preview/contentful`

| Export                                                       | Description                                                                                                                    |
| ------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------ |
| `CONTENTFUL_ENVIRONMENT_VARIABLES`                           | Names, required/secret flags, purposes, aliases.                                                                               |
| `contentfulEnvironmentFromEnv(env?, { region?, require? })`  | Reads space, environment, region, tokens, secret. Throws naming a missing variable.                                            |
| `contentfulEnvironmentReport(env?)`                          | Presence-only report.                                                                                                          |
| `contentfulRestBaseUrl(env, preview)`                        | Preview or Delivery API base URL.                                                                                              |
| `contentfulGraphqlUrl(env)`                                  | The GraphQL endpoint (same for both modes).                                                                                    |
| `contentfulAccessToken(env, preview)`                        | Preview token when active, delivery token otherwise.                                                                           |
| `contentfulRequestHeaders(env, preview)`                     | `Authorization: Bearer …`.                                                                                                     |
| `contentfulClientOptions(env, preview)`                      | `{ space, environment, accessToken, host }` for `createClient`.                                                                |
| `contentfulEntryEditorUrl(env, entryId)`                     | Deep link to the entry in the web app.                                                                                         |
| `contentfulLivePreviewInitConfig(config, state, overrides?)` | The `ContentfulLivePreview.init` / provider props shape. No secret.                                                            |
| `contentfulFieldId(graphqlField)`                            | `itemsCollection` → `items`.                                                                                                   |
| `contentfulLiveUpdateIssues(data, "rest" \| "graphql")`      | Why live updates could not match this data; `[]` when fine.                                                                    |
| `assertContentfulLiveUpdateShape(data, api)`                 | Throws on issues.                                                                                                              |
| `resolveEnableDraftRequest(env, url, options?)`              | `{ action: "enable", redirectTo, locale? } \| { action: "reject", status, reason }`.                                           |
| `resolveDisableDraftRequest(url, options?)`                  | `{ action: "disable", redirectTo }`.                                                                                           |
| `contentfulPreviewUrlTemplate(config, siteOrigin, options?)` | The Contentful → Content preview URL with a placeholder secret; `options.fullPathField` for a field that stores the full path. |
| `contentfulPreviewUrlTemplates(config, siteOrigin)`          | `{ slug, fullPath }`: both URL forms with `&locale={locale}`.                                                                  |

## `@eight25-factory/live-preview/contentstack`

| Export                                                                    | Description                                                                                                                                          |
| ------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------- |
| `CONTENTSTACK_ENVIRONMENT_VARIABLES`                                      | Names, required/secret flags, purposes.                                                                                                              |
| `contentstackEnvironmentFromEnv(env?, { region?, require? })`             | Reads api key, environment, branch, region, host overrides, tokens.                                                                                  |
| `contentstackEnvironmentReport(env?)`                                     | Presence-only report.                                                                                                                                |
| `contentstackPublicEnvironment(env)`                                      | `{ apiKey, environment, branch, appOrigin }` — safe for the browser.                                                                                 |
| `contentstackRestBaseUrl(env, state?)`                                    | `https://<delivery or preview host>/v3`.                                                                                                             |
| `contentstackGraphqlUrl(env, state?)`                                     | GraphQL or GraphQL-preview endpoint.                                                                                                                 |
| `contentstackRequestHeaders(env, state?)`                                 | `api_key`, `access_token`, `branch`; plus `live_preview`, `preview_token`, `include_applied_variants`, `preview_timestamp`, `release_id` in preview. |
| `contentstackPreviewQueryParams(state?)`                                  | The same session values as query parameters.                                                                                                         |
| `contentstackStackConfig(config, env)`                                    | Constructor config for the delivery SDK with `live_preview` enabled. Server-only.                                                                    |
| `contentstackLivePreviewQuery(state?)`                                    | Argument for `stack.livePreviewQuery(...)`, or `undefined`.                                                                                          |
| `contentstackEntryEditorUrl(env, { contentTypeUid, entryUid, locale? })`  | Deep link to the entry.                                                                                                                              |
| `contentstackLivePreviewInitConfig(config, publicEnv, state, overrides?)` | The `ContentstackLivePreview.init` shape. No secret.                                                                                                 |
| `contentstackFieldPath(...segments)`                                      | Joins a path; strips `Connection`, skips `edges`/`node`.                                                                                             |
| `editableTagsOf(entry, options?)`                                         | Top-level `$` map without mutating.                                                                                                                  |
| `attachEditableTags(entry, options?)`                                     | Sets `$` on the entry and every nested object; returns the entry.                                                                                    |
| `editableTag(tagged, key)`                                                | Reads one tag off a `$` map; `{}` when absent.                                                                                                       |
| `emptyBlockParentProps()`                                                 | `{ className: "visual-builder__empty-block-parent" }`.                                                                                               |

## `@eight25-factory/live-preview/next`

| Export                                                                     | Description                                                                                                                                                                                                          |
| -------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `loadNextLivePreview(options)`                                             | Validates once; accepts an already-resolved config.                                                                                                                                                                  |
| `withLivePreview(nextConfig, options)`                                     | Adds/merges the `frame-ancestors` header rule, removes `X-Frame-Options`. Async.                                                                                                                                     |
| `livePreviewHeaderRules(config, source?)`                                  | The rule(s) alone.                                                                                                                                                                                                   |
| `nextPreviewState(config, { searchParams?, cookies?, draftModeEnabled? })` | Accepts Next's cookie store shape. Sets `staleDraftCookie` when the draft cookie is present and `draftModeEnabled` is false. The marker cookie is ignored unless configured.                                         |
| `livePreviewClientConfig(config, state, environment, { locale?, debug? })` | Provider props: `ContentfulClientConfig \| ContentstackClientConfig`. No secret. `debug` from `livePreviewDebugEnabled(process.env)`.                                                                                |
| `createEnableDraftHandler(env, { enable, cookies? }, options?)`            | `(Request) => Response` for the enable route. With `cookies: () => cookies()` it re-issues the draft cookie `SameSite=None; Secure; HttpOnly` in development; `options.draftCookie: { partitioned?, development? }`. |
| `framedDraftCookie(value, options?)`, `DRAFT_MODE_COOKIE_NAME`             | The cookie attributes the fix sets; `"__prerender_bypass"`.                                                                                                                                                          |
| `createDisableDraftHandler({ disable }, options?)`                         | `(Request) => Response` for the disable route.                                                                                                                                                                       |
| `isDraftModeRequest({ cookies })`                                          | True when a `NextRequest`, cookie store or map carries the draft cookie. For middleware.                                                                                                                             |
| `applyPreviewCacheHeaders(headers)`                                        | Writes `PREVIEW_CACHE_HEADERS` onto a `Headers`.                                                                                                                                                                     |
| `nextFetchCacheOptions(state)`                                             | `{ cache: "no-store" }` in preview, `{}` otherwise.                                                                                                                                                                  |
| `PREVIEW_CACHE_HEADERS`                                                    | `Cache-Control` + `CDN-Cache-Control: no-store` for preview responses.                                                                                                                                               |
| `NextHeaderRule`, `NextConfigLike`                                         | Mutable shapes compatible with Next's `Header` and `NextConfig`; `withLivePreview(nextConfig)` types as `Promise<typeof nextConfig>`.                                                                                |

## `@eight25-factory/live-preview/nuxt`

| Export                                                                | Description                                                             |
| --------------------------------------------------------------------- | ----------------------------------------------------------------------- |
| `loadNuxtLivePreview(options)`                                        | Validates once.                                                         |
| `livePreviewPublicRuntimeConfig(config)`                              | `runtimeConfig.public.livePreview`. No secret.                          |
| `livePreviewRouteRules(config)`                                       | `{ "/**": { headers: { "Content-Security-Policy": … } } }`.             |
| `applyLivePreviewToNuxt(nuxt, config, { routeRules? })`               | Merges both into a Nuxt instance; app rules win.                        |
| `livePreviewNuxtModule(config)` (default export)                      | A module wrapping the above.                                            |
| `nuxtPreviewState(config, { query?, cookies? })`                      | From `getQuery(event)` and `parseCookies(event)`.                       |
| `nuxtPreviewCookie(config, "set" \| "clear", options?)`               | `{ name, value, options }` for h3's `setCookie`.                        |
| `livePreviewNuxtClientState(config, state, environment, { locale? })` | The per-request client state for `useState("live-preview")`. No secret. |

## `@eight25-factory/live-preview/templates`

| Export                                                                              | Description                                                                                                     |
| ----------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------- |
| `wiringFiles(options)`                                                              | The generated application files for a framework + provider.                                                     |
| `wiringInstructions(options)`                                                       | The manual steps that remain. `options.fetchHelpers` and `options.nextConfigFile` pick the variant.             |
| `patchNextConfigSource(source)`, `patchRootLayoutSource(source, { alias, srcDir })` | Pure patches for the create-next-app files → `{ status: "patched" \| "already" \| "manual", source, reason? }`. |
| `componentFile(options)`                                                            | A React (server or client) or Vue component scaffold with tagged fields.                                        |
| `claudeSkillFile(body)`, `cursorRuleFile(body)`, `agentsPointerSection()`           | Skill installation targets.                                                                                     |
| `renderTemplate(template, variables)`                                               | `__KEY__` substitution.                                                                                         |
| `PACKAGE_NAME`, `SKILL_NAME`                                                        | Constants.                                                                                                      |

## `@eight25-factory/live-preview/cli`

| Export                                                                                                                 | Description                                                               |
| ---------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------- |
| `parseCommand(argv)`                                                                                                   | argv → `Command` or `undefined` (help).                                   |
| `nextSetupQuestion(answers, context)`                                                                                  | The next unanswered question, or `undefined`.                             |
| `applyAnswer(answers, question, value)`                                                                                | Validates and applies one answer.                                         |
| `resolveSetup(answers, context, srcDir)`                                                                               | Complete setup with defaults.                                             |
| `buildSetupPlan(setup)`                                                                                                | `{ files, instructions, config }`; validates the config it writes.        |
| `writeFiles(files, directory, force?)`                                                                                 | `{ written, skipped }`.                                                   |
| `installSkills(targets, directory, force?, env?)`                                                                      | Writes the skill files and the AGENTS.md pointer.                         |
| `packageRoot(env?)`, `readSkillBody(env?)`                                                                             | Locate and read the shipped `SKILLS.md`.                                  |
| `environmentReport(provider, env)`, `configuredProviders(env)`                                                         | Presence-only environment inspection.                                     |
| `SETTING_ENVIRONMENT_VARIABLES`                                                                                        | Variables that answer setup questions.                                    |
| `patchNextProject(setup, directory)`, `detectNextConfigFile(directory)`                                                | Apply the patches to a project; find `next.config.*`.                     |
| `runDoctor(options, fetch?)`, `formatDoctorReport(report)`                                                             | The `doctor` checks against a running app, with a fake `fetch` for tests. |
| `assessDraftCookie`, `assessFrameHeaders`, `assessCacheHeaders`, `countTags`, `serializedActiveFlag`, `parseSetCookie` | The individual doctor assessors.                                          |
| `runInit(command, context, directory)`, `main(argv?)`                                                                  | The interactive flow and the entrypoint.                                  |
