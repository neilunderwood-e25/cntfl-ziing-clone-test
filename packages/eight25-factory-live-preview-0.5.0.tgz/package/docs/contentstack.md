# Contentstack

Contentstack's editing surfaces share one mechanism, and this package wires
all of it:

| Surface            | What it is                                                          | What makes it work                                                      |
| ------------------ | ------------------------------------------------------------------- | ----------------------------------------------------------------------- |
| **Live Preview**   | The entry editor frames your site and shows the draft as you type   | `live_preview` hash + preview token + preview hosts + `frame-ancestors` |
| **Edit tags**      | Hovering a field shows an Edit button that focuses it in the editor | `data-cslp="content_type.uid.locale.field.path"`                        |
| **Visual Builder** | Click-to-edit, add/remove blocks, in a WYSIWYG canvas               | Same tags, `?builder=true`, empty-block marker                          |
| **Timeline**       | Preview the site as of a scheduled date                             | `preview_timestamp` forwarded with the request                          |

## Credentials

```dotenv
# .env.local — ignored by git. Set the same names in hosted build environments.
CONTENTSTACK_API_KEY=
CONTENTSTACK_ENVIRONMENT=
CONTENTSTACK_BRANCH=main
CONTENTSTACK_REGION=us
CONTENTSTACK_DELIVERY_TOKEN=
CONTENTSTACK_PREVIEW_TOKEN=
```

| Variable                            | Required | Secret | Notes                                                              |
| ----------------------------------- | -------- | ------ | ------------------------------------------------------------------ |
| `CONTENTSTACK_API_KEY`              | yes      | no     | Also the SDK's `stackDetails.apiKey` in the browser                |
| `CONTENTSTACK_ENVIRONMENT`          | yes      | no     |                                                                    |
| `CONTENTSTACK_DELIVERY_TOKEN`       | yes      | yes    |                                                                    |
| `CONTENTSTACK_PREVIEW_TOKEN`        | yes      | yes    | Tokens → Delivery tokens → create with Preview enabled             |
| `CONTENTSTACK_BRANCH`               | no       | no     | Defaults to `main`                                                 |
| `CONTENTSTACK_REGION`               | no       | no     | `us`, `na`, `eu`, `au`, `azure-na`, `azure-eu`, `gcp-na`, `gcp-eu` |
| `CONTENTSTACK_APP_HOST`             | no       | no     | Override the web app origin used for framing                       |
| `CONTENTSTACK_PREVIEW_HOST`         | no       | no     | Override the REST preview host                                     |
| `CONTENTSTACK_GRAPHQL_PREVIEW_HOST` | no       | no     | Override the GraphQL preview host                                  |

`npx live-preview check-env --provider contentstack` reports presence only.

## Preview mode: the `live_preview` hash

When an editor opens Live Preview, Contentstack loads the configured Preview
URL with parameters appended:

```
https://<site>/about?live_preview=<hash>&content_type_uid=page&entry_uid=blt...&preview_timestamp=...&builder=true
```

The **hash identifies the draft version**; it changes on every edit. So:

- `resolvePreviewState` reads it from the query string: `active: true,
source: "query", contentstack: { hash, contentTypeUid, entryUid, ... }`,
  `builder: true` when `?builder=true`.
- Server code must receive the query string. In Next, the **page** calls
  `getPreviewState(await searchParams)`; layouts cannot see it, so the
  provider gets a static bootstrap and `hydrateContentstackClient` finishes it
  from `window.location` in the browser.
- Internal links must carry the parameters or the next page is production.
  The generated provider/plugin appends them on click;
  `withPreviewParams(href, config, state)` does it for URLs you build.

Stack settings: Settings → Live Preview → enable; Preview URL per environment
(and per locale on translated stacks), e.g. `https://staging.example.com`.
On a password-protected host the Preview URL must not carry a query string
of its own, or Contentstack's concatenation breaks the path.

## Hosts and requests

| Region                         | App origin                              | Delivery                  | REST preview                       | GraphQL preview                       |
| ------------------------------ | --------------------------------------- | ------------------------- | ---------------------------------- | ------------------------------------- |
| `us`, `na`                     | `https://app.contentstack.com`          | `cdn.contentstack.io`     | `rest-preview.contentstack.com`    | `graphql-preview.contentstack.com`    |
| `eu`                           | `https://eu-app.contentstack.com`       | `eu-cdn.contentstack.com` | `eu-rest-preview.contentstack.com` | `eu-graphql-preview.contentstack.com` |
| `au`                           | `https://au-app.contentstack.com`       | `au-cdn.contentstack.com` | `au-rest-preview.contentstack.com` | `au-graphql-preview.contentstack.com` |
| `azure-na`                     | `https://azure-na-app.contentstack.com` | `azure-na-cdn.…`          | `azure-na-rest-preview.…`          | `azure-na-graphql-preview.…`          |
| `azure-eu`, `gcp-na`, `gcp-eu` | same pattern                            |                           |                                    |                                       |

In a preview session:

- **REST**: `contentstackRestBaseUrl(env, state)` → the preview host;
  `contentstackRequestHeaders(env, state)` adds `live_preview`,
  `preview_token`, `include_applied_variants`, and `preview_timestamp` /
  `release_id` when present; `contentstackPreviewQueryParams(state)` gives the
  same as query parameters for clients that cannot set headers.
- **GraphQL**: `contentstackGraphqlUrl(env, state)` → the `graphql-preview`
  host; same headers.
- **Official delivery SDK** (`contentstack` v3 or `@contentstack/delivery-sdk`):
  `contentstackStackConfig(config, env)` returns the constructor config with
  `live_preview: { enable, host, preview_token }`;
  `contentstackLivePreviewQuery(state)` returns the argument for
  `stack.livePreviewQuery(...)`, or `undefined` outside preview.

Never cache a preview response.

## Edit tags (`data-cslp`)

```html
<h1 data-cslp="page.blt0123456789.en-us.blocks.0.hero.heading"></h1>
```

Format: `content_type_uid.entry_uid.locale.field.path`, locale lowercase.
`tagsFor(config, state, entry)("blocks.0.hero.heading")` builds it, taking
`uid`, `_content_type_uid`, and `locale` from the entry (REST) or
`system { uid content_type_uid locale }` (GraphQL).

Field paths:

| Field kind         | Path                                                                                                                |
| ------------------ | ------------------------------------------------------------------------------------------------------------------- |
| Simple             | `title`                                                                                                             |
| Group              | `seo.meta_title`                                                                                                    |
| Multiple group     | `cards.0.title`                                                                                                     |
| Modular blocks     | `blocks.0.hero.heading` (block uid after the index)                                                                 |
| Reference          | The referenced entry restarts with **its own** identity                                                             |
| GraphQL connection | `heroConnection.edges[0].node` → `hero.0`; `contentstackFieldPath("heroConnection", "edges", 0, "node", "heading")` |

Codebases that already use `addEditableTags` from `@contentstack/utils`
spread `entry.$.field`. This package's `attachEditableTags(entry)` produces
the same `$` map (including `field__0` per array item) and also understands
GraphQL responses, which the official helper does not; `editableTag(entry, "field")`
reads one entry safely. System keys (`uid`, `locale`, `publish_details`, …)
are not tagged.

## Visual Builder

Same tags; `?builder=true` in the URL. `contentstack.mode: "auto"` (default)
initializes the SDK in `builder` mode when that parameter is present and
`preview` otherwise, so one deployment serves both. The parameter is carried
across internal links.

An **empty modular-block list** needs a container that renders even when empty
and carries `class="visual-builder__empty-block-parent"`
(`emptyBlockParentProps()`), or the builder cannot offer "Add block".

## SSR and CSR modes

`contentstack.ssr` (default `true`) is passed to the SDK:

- **`ssr: true`** — on each edit the SDK fetches the current URL with the new
  hash and patches the DOM. Nothing else is needed; Server Components and
  Nuxt SSR pages update without client code.
- **`ssr: false`** — the app owns updates. The generated Next provider calls
  `router.replace` with the new hash on `onEntryChange`; the Nuxt plugin
  re-routes and `refreshNuxtData()`; `useLiveEntry(entry, refetch)` re-runs a
  client fetch that must send `ContentstackLivePreview.hash`.

## Locales

Tags use lowercase locale codes (`en-us`), read from the entry, then `?locale=`,
then `contentstack.defaultLocale`. Translated stacks configure a Preview URL
per locale so the editor opens the right prefix.

## Failure modes

| Symptom                                   | Cause                                                                                   |
| ----------------------------------------- | --------------------------------------------------------------------------------------- |
| Preview panel blank                       | `X-Frame-Options` or CSP without the region's app origin; wrong Preview URL             |
| Published content shown                   | `searchParams` not passed to `getPreviewState`; fetch on delivery host; cached response |
| Edit button on some fields only           | Untagged element or wrong field path                                                    |
| Edit button nowhere                       | Tags suppressed (state inactive), SDK not initialized, `editButton.enable: false`       |
| First edit updates, later ones do not     | `ssr: false` without re-sending the new hash                                            |
| Clicking a link drops out of preview      | Custom anchor bypassing the click handler; server redirect stripping the query          |
| "Add block" missing on empty list         | Empty-block marker class missing, or container not rendered when empty                  |
| Home page opens instead of the entry      | Preview URL in stack settings carries its own query string (host bypass params)         |
| Entry visible in editor, `404` in preview | Entry not published to `CONTENTSTACK_ENVIRONMENT` and no hash reached the request       |
