# Nuxt

Complete wiring for Nuxt 3 and Nitro. `npx live-preview init --write`
generates every file below.

## What Nuxt needs from you

1. The CMS may **frame** the site (server middleware sets `frame-ancestors`).
2. A **server plugin** decides the preview state per request and a **client
   plugin** starts the SDK from it.
3. Every CMS request on a previewed page **follows the preview state**.
4. Components **tag fields** with `useFieldTags` and wrap entries in
   `useLiveEntry`.

## 1. Configuration

```js
// live-preview.config.mjs
export const livePreviewOptions = {
  provider: "contentstack", // or "contentful"
  framework: "nuxt",
  contentstack: {
    region: "us",
    mode: "auto",
    ssr: true,
    defaultLocale: "en-us",
  },
};
```

```ts
// nuxt.config.ts
import {
  livePreviewPublicRuntimeConfig,
  loadNuxtLivePreview,
} from "@eight25-factory/live-preview/nuxt";
import { livePreviewOptions } from "./live-preview.config.mjs";

const livePreview = loadNuxtLivePreview(livePreviewOptions);

export default defineNuxtConfig({
  runtimeConfig: {
    public: { livePreview: livePreviewPublicRuntimeConfig(livePreview) }, // no secrets
  },
});
```

`livePreviewRouteRules(livePreview)` is available too, but route rules replace
a `Content-Security-Policy` header rather than merging into it; the generated
middleware merges, so prefer it when the app already sets a CSP (for example
through `nuxt-security`).

## 2. The server util

`server/utils/live-preview.ts` is the only file that reads tokens:

| Export                                                                                | Purpose                                                                   |
| ------------------------------------------------------------------------------------- | ------------------------------------------------------------------------- |
| `livePreviewConfig`                                                                   | The validated configuration.                                              |
| `previewStateFor(event)`                                                              | The request's preview decision from `getQuery(event)` and `parseCookies`. |
| `clientStateFor(event, locale?)`                                                      | Token-free state for the client plugin.                                   |
| `previewTags(state, entry)`                                                           | Server-side tagging for server-rendered HTML you build yourself.          |
| `contentfulGraphql` / `contentfulClient`                                              | Preview-aware requests (Contentful).                                      |
| `contentstackGraphql` / `contentstackRest` / `contentstackStack` / `livePreviewQuery` | Preview-aware requests (Contentstack).                                    |

## 3. Plugins

`plugins/live-preview.server.ts` runs once per request on the server, calls
`clientStateFor(event)`, and stores the result in `useState("live-preview")`.
`plugins/live-preview.client.ts` reads it and, when the session is active:

- **Contentful**: `ContentfulLivePreview.init(...)` and a `save` subscription
  that calls `refreshNuxtData()`.
- **Contentstack**: `hydrateContentstackClient` finishes the session from
  `window.location.search`, then `ContentstackLivePreview.init(...)`; with
  `ssr: false` it also re-routes with the new hash on `onEntryChange`. It
  carries the session parameters across internal link clicks.

Nothing runs outside preview.

## 4. Middleware

`server/middleware/live-preview.ts` merges `frame-ancestors` into any existing
`Content-Security-Policy`, removes `X-Frame-Options`, and sets
`Cache-Control: no-store` on preview responses.

## 5. Fetching data

Fetch on the server so the tokens stay there:

```ts
// server/api/page.get.ts
import { contentstackGraphql, previewStateFor } from "../utils/live-preview";

export default defineEventHandler(async (event) => {
  const state = previewStateFor(event);
  const { slug } = getQuery(event);
  return contentstackGraphql(PAGE_QUERY, { slug }, state);
});
```

```vue
<!-- pages/[...slug].vue -->
<script setup lang="ts">
const route = useRoute();
// Forward the query so the live_preview hash reaches the server route.
const { data: page } = await useAsyncData(`page:${route.path}`, () =>
  $fetch("/api/page", { query: { slug: route.path, ...route.query } }),
);
</script>
<template>
  <Hero v-if="page?.hero" :hero="page.hero" />
</template>
```

With the official Contentstack SDK instead: `const stack = contentstack.Stack(contentstackStack())`,
then `const q = livePreviewQuery(state); if (q) stack.livePreviewQuery(q)`
before querying.

## 6. Composables

```ts
const session = useLivePreview(); // Ref<LivePreviewNuxtClientState | null>
const tag = useFieldTags(entry); // (field) => attributes, {} outside preview
const live = useLiveEntry(entryRef); // live-updating ref (Contentful), mirror (Contentstack ssr)
```

```vue
<script setup lang="ts">
const props = defineProps<{ hero: Entry }>();
const live = useLiveEntry(toRef(props, "hero"));
const tag = useFieldTags(live);
</script>
<template>
  <section>
    <h1 v-if="live.title" v-bind="tag('title')">{{ live.title }}</h1>
    <p v-if="live.body" v-bind="tag('body')">{{ live.body }}</p>
  </section>
</template>
```

`useFieldTags` works during SSR and on the client from the same state, so
markup hydrates without mismatches.

## 7. Preview session routes (Contentful)

Nuxt has no draft mode, so a cookie marks the session:

```ts
// server/api/live-preview/enable.get.ts
import { resolveEnableDraftRequest } from "@eight25-factory/live-preview/contentful";
import { nuxtPreviewCookie } from "@eight25-factory/live-preview/nuxt";
import {
  contentfulEnvironment,
  livePreviewConfig,
} from "../../utils/live-preview";

export default defineEventHandler((event) => {
  const decision = resolveEnableDraftRequest(
    contentfulEnvironment,
    getRequestURL(event).toString(),
  );
  if (decision.action === "reject")
    throw createError({
      statusCode: decision.status,
      statusMessage: decision.reason,
    });
  const cookie = nuxtPreviewCookie(livePreviewConfig, "set", {
    secure: getRequestURL(event).protocol === "https:",
  });
  setCookie(event, cookie.name, cookie.value, cookie.options);
  return sendRedirect(event, decision.redirectTo, 307);
});
```

The cookie is `SameSite=None; Secure`, because the site is a third party
inside the editor's frame. Its name comes from `detection.cookieName`
(default `e25_live_preview`); it is a session marker, not a secret.

## Checklist

- [ ] `runtimeConfig.public.livePreview` set from `livePreviewPublicRuntimeConfig`
- [ ] Both plugins and the middleware present
- [ ] Server routes call `previewStateFor(event)` and use the generated fetch
      helpers
- [ ] Pages forward `route.query` to server routes (Contentstack hash)
- [ ] Components use `useFieldTags` and `useLiveEntry`
- [ ] Contentful: enable/disable routes deployed, preview URL set in Contentful
- [ ] Contentstack: Live Preview enabled, Preview token created
- [ ] Production HTML has no `data-contentful-*` / `data-cslp`
