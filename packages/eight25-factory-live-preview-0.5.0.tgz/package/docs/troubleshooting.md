# Troubleshooting

Work top to bottom; each row isolates one layer. The same table lives in
[SKILLS.md](../SKILLS.md) for agents. With the app running,
`npx live-preview doctor http://localhost:3000` performs the first four
sections' checks in one go and prints a table.

## The preview panel is blank or says the site refused to connect

| Check                                 | Fix                                                                                                                                                                                                                                 |
| ------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Response headers on the previewed URL | Must include `Content-Security-Policy: frame-ancestors 'self' <editor origin>` and **no** `X-Frame-Options`. `withLivePreview` / the Nuxt middleware handle the app; hosting dashboards and CDNs add their own — remove them there. |
| Editor origin matches the region      | `https://app.contentful.com` vs `https://app.eu.contentful.com`; `https://eu-app.contentstack.com`, … Set `region`.                                                                                                                 |
| Preview URL in the CMS                | Points at the right host and, for Contentful, at the enable route with `secret=` and `path=` (or `slug=`). A `404` means the route path differs from `contentful.draftMode.enablePath`.                                             |
| Contentstack + protected host         | The stack's Preview URL must not carry a query string; Contentstack concatenates the entry path onto it.                                                                                                                            |

## The status dialog shows both features "Disabled" but the page renders

The frame loads, the site looks right, but the SDK never connects and nothing
is tagged. Thirty-second check, in the browser console **with the iframe
selected as the JavaScript context** (DevTools → context dropdown):

```js
document.querySelectorAll("[data-contentful-entry-id]").length;
```

`0` means the server rendered this request as production. Causes, in order
of likelihood:

| Check                                       | Fix                                                                                                                                                                                                                                                                                                                                                                                           |
| ------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `next dev` and the cookie is `SameSite=Lax` | Next's dev server issues the draft cookie `SameSite=Lax` without `Secure`; browsers never send it to a page framed by `app.contentful.com`. Production builds use `SameSite=None; Secure`. The generated enable route passes `cookies: () => cookies()` to `createEnableDraftHandler`, which re-issues the cookie frame-safe in development. `doctor` reports the attributes it actually got. |
| Stale session after a restart or deploy     | Next mints a new draft secret on every `next dev` start and every build, so the cookie in the browser is no longer recognised. The panel's refresh button reloads the page URL, not the enable URL. `state.staleDraftCookie` is true and the provider shows "Preview session expired"; reopen the preview from the entry.                                                                     |
| Third-party cookies blocked                 | Safari, or Chrome with third-party cookies off, drops the cookie inside the frame regardless of attributes. Pass `{ draftCookie: { partitioned: true } }` to the handler (CHIPS); the cookie is then not sent when the editor opens the page in a new tab.                                                                                                                                    |
| Enable route answered `401`                 | Secret mismatch: `CONTENTFUL_PREVIEW_SECRET` where the app runs differs from the value in the Contentful preview URL, or is unset there.                                                                                                                                                                                                                                                      |
| `getPreviewState` never sees draft mode     | The page reads the state from something other than `draftMode()` (a custom cookie, a query parameter). On Next only draft mode activates preview; the package's marker cookie is ignored unless `detection.cookieName` is configured explicitly.                                                                                                                                              |

## The page shows published content, not the draft

| Check                                                      | Fix                                                                                                                                                              |
| ---------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Contentful: did the enable route run?                      | `401` → secret mismatch or `CONTENTFUL_PREVIEW_SECRET` unset where the route runs. `400` → `path` not a same-origin path. `404` → wrong route path.              |
| Contentful: is the draft-mode cookie present in the frame? | See the section above: dev-mode `Lax` cookie, stale session, third-party cookies.                                                                                |
| Contentstack: does the server see the hash?                | The **page** must call `getPreviewState(await searchParams)`; layouts and nested components cannot see the query. Nuxt server routes must receive `route.query`. |
| Is the fetch preview-aware?                                | Preview host + preview token when active. Use the generated helpers, or pass `state.active` into your own client as the preview flag with `cache: "no-store"`.   |
| Is anything caching?                                       | Data Cache (`no-store` when active), Nitro rules, CDN. Check `Cache-Control`, `CDN-Cache-Control` and `Age` on the preview response; `doctor` checks them.       |

## No Edit button / no outline on hover

| Check                                     | Fix                                                                                                                                                      |
| ----------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Are tags in the HTML at all?              | `view-source` for `data-contentful-entry-id` / `data-cslp`. None → state inactive (see above) or `tags.policy: "never"`.                                 |
| Only some fields                          | Those elements are untagged, or tagged with the wrong field id / path, or the tag sits on a wrapper rather than the element (SKILLS.md R1).              |
| Contentful: all three attributes present? | `entry-id`, `field-id`, **and** `locale` on the same element; without locale the Edit affordance never appears.                                          |
| Is the SDK running?                       | Set `LIVE_PREVIEW_DEBUG=1` (or `contentful.debugMode` / `contentstack.debug`) and read the console. Provider missing from the layout is the usual cause. |
| Contentstack: right locale in the tag?    | Lowercase, matching the stack's locale code.                                                                                                             |

## Typing does not update the page

| Check                                           | Fix                                                                                                                                                                       |
| ----------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Contentful: panel says "Live updates: Disabled" | Data lacks `sys.id` / `__typename`, or was transformed before `useLiveEntry`. Run `contentfulLiveUpdateIssues(data, api)`.                                                |
| Contentful: a collection field never updates    | `xCollection.items` was flattened to `x[]` (or otherwise reshaped) before `useLiveEntry`. The SDK matches by the GraphQL shape it knows; pass the record as fetched (R3). |
| Contentful: updates arrive after a few seconds  | Server Component path: refresh on autosave. Expected. Use a Client Component with `useLiveEntry` for keystrokes.                                                          |
| Contentstack: nothing after the first edit      | `ssr: false` without re-sending the new `ContentstackLivePreview.hash`; or a stale `router.refresh()`.                                                                    |
| Contentstack `ssr: true`: DOM not patched       | The re-fetched URL is cached, or a redirect strips the query.                                                                                                             |

## `Live updates are not initialized, please call ContentfulLivePreview.init() first`

Thrown in **production** (or any request outside a preview session) by a
Client Component. The provider deliberately does not start the SDK outside
preview, and `useContentfulLiveUpdates` subscribes in its effect regardless.
The generated `useLiveEntry` passes `skip` whenever the session is inactive;
if you call the SDK hook directly, do the same:
`useContentfulLiveUpdates(entry, { skip: !useLivePreview()?.active })`.
Regenerate the file with `init --write --force` if yours predates this.

## Type error in `next.config.ts`

`withLivePreview(nextConfig, …)` returns `Promise<NextConfig>` for the config
type you pass in, and `livePreviewHeaderRules` returns Next's mutable
`Header[]`. If you see "index signature is missing" or "readonly … is not
assignable", the package is older than 0.4; update it. Export the promise
directly: `export default withLivePreview(nextConfig, livePreviewOptions);`.

## Build fails without environment variables

`Missing required environment variable CONTENTFUL_SPACE_ID` during
`next build`, a CI type-check, or on a fresh clone means a module reads the
environment at import time. The generated `lib/live-preview/server.ts` reads
it per call: `getLivePreviewClientConfig()` returns `null` when the space id
is unset (the layout renders without the provider) and the enable route
builds its handler inside `GET`. If you customised the file, keep both
properties. Regenerate with `init --write --force` to compare.

## Clicking a link leaves preview

Contentstack appends its parameters to the first URL only. The generated
provider/plugin appends them on click for same-origin anchors; a custom
`location.assign`, a `<form>` navigation, or a server redirect that drops the
query bypasses it. Use `withPreviewParams(href, config, state)` for URLs you
build.

## Tags or SDK requests appear in production

`tags.policy` is `always`, someone hand-wrote an attribute, or the SDK is
initialized outside the generated provider. Grep for `data-cslp`,
`data-contentful-`, `ContentfulLivePreview`, `ContentstackLivePreview`.
`doctor` fetches the page without the draft cookie and fails on any tag.

## Draft HTML served to a visitor (CDN)

A response rendered inside a draft session was stored by the CDN. Middleware
must mark every request carrying the draft cookie `private, no-store`
(`isDraftModeRequest` + `applyPreviewCacheHeaders`), and only draft mode may
activate preview on Next — never an unsigned cookie or `?locale=`.

## Hydration mismatch in preview

Server and client computed different tags: different `active` or locale. Pass
the same `state` the page resolved; do not recompute preview state in a
component. Contentstack + Next: the layout's bootstrap is inactive by design;
tags there come from the client after hydration, so tag in pages and
components, not in the layout.

## `LivePreviewValidationError`

The message names the path: `config.tags.polciy: is not supported`,
`tag.contentTypeId: is required for Contentstack tags`, `entry: has no sys.id`.
Fix the configuration or the query it names. A `null` or `undefined` record
does not throw: it yields a tagger that emits nothing, for optional
references.

## `Missing required environment variable X`

Set the **name** in `.env.local` and the host's build environment;
`npx live-preview check-env` confirms presence without printing values.
