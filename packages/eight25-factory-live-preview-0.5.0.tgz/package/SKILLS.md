# Live preview skills

Instructions for an AI agent building or changing front-end components in a
project that uses `@eight25-factory/live-preview`. The goal of every skill
here is one outcome: **an editor opens an entry in the CMS, sees the page in
the preview panel, hovers a field and gets an Edit affordance, types, and the
page updates.** For Contentful that is _inspector mode_ plus _live updates_;
for Contentstack it is _Live Preview_ plus the _Visual Builder_.

Apply these skills whenever you create a component that renders CMS content,
change what an existing component renders, wire preview into an application,
or review a pull request that touches either. When a skill and the surrounding
codebase disagree, follow the codebase's existing generated files under
`lib/live-preview/`, `components/live-preview/`, `composables/`, or
`server/utils/` — they are the source of truth for names — and say so.

---

## Skill 0 — Know the stack before writing anything

Establish, from files, not guesses:

| Question                    | Where the answer is                                                                                                                            |
| --------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------- |
| Next.js or Nuxt?            | `next.config.*` / `nuxt.config.*` and `package.json`                                                                                           |
| Contentful or Contentstack? | `live-preview.config.mjs` → `provider`; else the SDK in `package.json`; else the `CONTENTFUL_*` / `CONTENTSTACK_*` variable _names_ in `.env*` |
| Is preview already wired?   | `live-preview.config.mjs` exists **and** the generated files below exist **and** the provider is rendered in the root layout / plugin          |
| Server or client component? | Next: no `"use client"` = Server Component. Nuxt: everything is a Vue component; SSR + client.                                                 |
| REST or GraphQL?            | Look at the data layer the page uses; the identity fields you must select differ (Skill 2, rules R2 and R3).                                   |
| `src/` directory?           | `src/app` or `src/components` present → paths below are prefixed with `src/`.                                                                  |

Generated wiring you should find (names are fixed by `npx live-preview init`):

```
Next.js                                        Nuxt
live-preview.config.mjs                        live-preview.config.mjs
lib/live-preview/config.ts                     server/utils/live-preview.ts
lib/live-preview/server.ts                     plugins/live-preview.server.ts
components/live-preview/context.tsx            plugins/live-preview.client.ts
components/live-preview/LivePreviewProvider.tsx composables/useLivePreview.ts
components/live-preview/useLiveEntry.ts        server/middleware/live-preview.ts
app/api/live-preview/{enable,disable}/route.ts server/api/live-preview/{enable,disable}.get.ts   (Contentful only)
```

If any of these is missing, do **Skill 1** first. Never inline SDK
initialization into a page or component to work around missing wiring.

Never print, log, commit, or paste the value of any `*_TOKEN` or `*_SECRET`
variable. Refer to variables by name only.

---

## Skill 1 — Wire live preview into an application

Run the package's own flow rather than composing it by hand:

```sh
npx @eight25-factory/live-preview check-env     # names only, never values
npx @eight25-factory/live-preview init --write  # asks only what the environment cannot answer;
                                                # adds the package and the CMS SDK to package.json,
                                                # patches next.config.* and app/layout.tsx
npx @eight25-factory/live-preview init --write --no-fetch-helpers   # the app already has a CMS client
npx @eight25-factory/live-preview doctor http://localhost:3000       # afterwards, against the running app
```

`init` prints the remaining manual steps. Complete **all** of them, or tell the
user exactly which one you left undone and why:

1. **Framing.** The CMS loads the site in an `<iframe>`. `withLivePreview` (Next)
   or the generated server middleware (Nuxt) sends
   `Content-Security-Policy: frame-ancestors 'self' <editor origin>`. Any
   `X-Frame-Options: DENY|SAMEORIGIN` anywhere in the stack — app, CDN, host
   settings — blanks the preview panel. Check the host too.
2. **Provider in the root layout / plugins.** One `<LivePreviewProvider>`
   around `{children}` in Next; both generated plugins in Nuxt. Nothing else
   initializes an SDK.
3. **Preview-aware data fetching.** Every CMS request goes through the
   generated helpers (`contentfulGraphql`, `contentstackGraphql`,
   `contentstackRest`, `contentfulClient`, `contentstackStack` +
   `livePreviewQuery`) or reproduces what they do: preview host/token when the
   state is active, **no caching while previewing**. An app that already has
   its own client keeps it: run `init --no-fetch-helpers` and pass
   `state.active` into that client as the preview flag (preview token +
   `cache: "no-store"` when true). Do not add a second client.
4. **Preview URL in the CMS.** Contentful: Settings → Content preview →
   `https://<site>/api/live-preview/enable?secret=<CONTENTFUL_PREVIEW_SECRET>&path=/{entry.fields.slug}&locale={locale}`,
   or `&path={entry.fields.url}` when the field stores the full path; `slug=`
   and `path=` are both accepted, `?locale=` is carried through.
   Contentstack: Settings → Live Preview → enable, Preview URL `https://<site>`
   (per-locale URLs on translated stacks), plus a Preview token.
5. **Cache headers on a CDN-cached site.** Middleware marks draft-mode
   requests `private, no-store` (`isDraftModeRequest` +
   `applyPreviewCacheHeaders` from `/next`). `?locale=` alone never opts a
   response out of caching.
6. **Verify with `doctor`.** `npx live-preview doctor <base-url>` against the
   running app checks the draft cookie's attributes (the `next dev` cookie is
   `SameSite=Lax` and is silently withheld inside the Contentful frame unless
   the generated enable route re-issues it), the tags, the serialized
   `active` flag, framing and cache headers, and that production HTML has no
   tags.
7. **Skill installed.** `npx live-preview install-skills` so the next agent
   finds this file in `.claude/skills/live-preview/SKILL.md`.

`init --write` patches `next.config.*` and `app/layout.tsx` when they have
the create-next-app shape and prints a snippet otherwise; do not skip the
snippet. `getLivePreviewClientConfig()` returns `null` on a checkout without
the CMS variables and the provider accepts `null`, so `next build` must pass
with and without them — never read the environment at module scope.

Do not add `NEXT_PUBLIC_*` copies of tokens. The client receives a
serializable, token-free config from the server (`getLivePreviewClientConfig`
/ `clientStateFor`). If a Client Component seems to need a token, the data
fetch belongs on the server.

---

## Skill 2 — Build a component that previews correctly

### Rules that apply to every component

**R1. Tag the element that renders the field, one field per element.**
The tag goes on the DOM element whose text/image _is_ the field, not on a
distant wrapper and not on several fields at once. Inspector mode outlines the
tagged element; the Visual Builder's click target is the tagged element.

**R2. Every rendered record must carry its identity.**

- Contentful: `sys { id }` on every entry and asset, at every nesting level;
  `__typename` too when using GraphQL. REST: `sys.id` and `sys.contentType`.
- Contentstack REST: `uid`, `_content_type_uid`, `locale` on every entry
  including referenced ones. GraphQL: `system { uid content_type_uid locale }`
  on every entry and every connection node.

Tagging throws when identity is missing on purpose — an untagged field is a
silent failure for editors. Fix the query, not the tag call.

**R3. Fetch and pass raw records. Transform after the live hook.**
Live updates match editor changes to your data by identity and field path. A
component that receives `{ heading: entry.title.toUpperCase() }` cannot be
updated. Pass `entry`; compute the uppercase inside render, after
`useLiveEntry`. This includes collections: flattening
`ctaCollection.items` into `cta[]` (or renaming any field) before
`useLiveEntry` breaks live updates for exactly those fields, while
everything else keeps working — the most confusing failure there is.
Flatten in render, from the live object.

**R4. Use the generated tag helpers; never write `data-contentful-*` or
`data-cslp` strings by hand.**
The helpers honour the tag policy (tags only during preview by default), the
locale, and the provider's attribute format.

**R5. Preview state flows from the request.**
Next: the page calls `getPreviewState(await searchParams)` once and passes
`state` down to Server Components as a prop. Nested Server Components may also
call `getPreviewState()` with no argument and get the same decision. Client
Components read it from context via `useFieldTags` / `useLivePreview`. Nuxt:
`previewStateFor(event)` on the server; composables read `useState`.

**R6. Contentstack lists that can be empty need the empty-block marker.**
The Visual Builder cannot offer "Add block" on an empty modular-block field
unless its container has `className="visual-builder__empty-block-parent"`
(`emptyBlockParentProps()`), and the container itself must render even when
the list is empty.

**R7. Internal links keep the session.**
Use the framework's link component; the provider/plugin already appends the
Contentstack preview parameters on click. Do not build URLs that strip the
query string, and do not `window.location.assign` to a bare path in preview.

**R8. Nothing preview-related affects production.**
Tags are emitted only while previewing; SDKs initialize only while previewing;
CMS requests are cached normally outside preview. If your change adds a
`"use client"` boundary or a client-side fetch purely for preview, reconsider:
Skill 2's Server Component recipe needs neither.

**R9. One locale per render.**
The tag locale defaults to the SDK locale (Contentful) or `defaultLocale`
(Contentstack), overridden by the entry's own locale, then by `?locale=`.
Multi-locale pages pass the page locale to `getLivePreviewClientConfig(locale)`
and to `previewTags(state, entry, { locale })` when the entry does not carry it.

**R10. Keep secrets on the server.**
Component code never imports the environment readers. Only
`lib/live-preview/server.ts` / `server/utils/live-preview.ts` read tokens.

### Recipe A — Next.js Server Component (default)

Use this unless the component genuinely needs client state.

```tsx
// components/Hero/index.tsx  (no "use client")
import type { PreviewState } from "@eight25-factory/live-preview";
import { previewTags } from "@/lib/live-preview/server";
import Image from "next/image";

type Entry = {
  sys: { id: string }; // R2
  __typename?: "Hero";
  title?: string | null;
  body?: string | null;
  image?: {
    sys: { id: string };
    url?: string | null;
    title?: string | null;
  } | null;
  ctaCollection?: {
    items: Array<{
      sys: { id: string };
      __typename?: "Cta";
      label?: string | null;
      href?: string | null;
    } | null>;
  } | null;
};

export default function Hero({
  hero,
  state,
}: {
  hero: Entry;
  state: PreviewState;
}) {
  const tag = previewTags(state, hero); // R4, R5

  return (
    <section>
      {hero.title ? <h1 {...tag("title")}>{hero.title}</h1> : null} {/* R1 */}
      {hero.body ? <p {...tag("body")}>{hero.body}</p> : null}
      {hero.image?.url ? (
        // An asset is its own record: tag it with its own identity, field "file".
        // previewTags(state, null | undefined) tags nothing, so optional
        // references need no guard around the tagger itself.
        <Image
          {...previewTags(state, hero.image)("file")}
          src={hero.image.url}
          alt={hero.image.title ?? ""}
          width={1200}
          height={600}
        />
      ) : null}
      {/* A reference list: tag the list with the parent's field id (GraphQL
          "ctaCollection" → field id "cta"), each item with its own identity. */}
      <ul {...tag("cta")}>
        {hero.ctaCollection?.items.filter(Boolean).map((cta) => (
          <li key={cta!.sys.id}>
            <a {...previewTags(state, cta)("label")} href={cta!.href ?? "#"}>
              {cta!.label}
            </a>
          </li>
        ))}
      </ul>
    </section>
  );
}
```

The page:

```tsx
// app/[...slug]/page.tsx
import { getPreviewState, contentfulGraphql } from "@/lib/live-preview/server";
import Hero from "@/components/Hero";

export default async function Page({ params, searchParams }) {
  const state = await getPreviewState(await searchParams); // R5 — once, at the top
  const { slug } = await params;
  const data = await contentfulGraphql<{
    pageCollection: { items: PageEntry[] };
  }>(
    PAGE_QUERY,
    { slug: slug.join("/") },
    state, // preview-aware, uncached in preview
  );
  const page = data.pageCollection.items[0];
  return <Hero hero={page.hero} state={state} />;
}
```

How updates reach a Server Component: the provider re-renders the route on
every editor save (Contentful) or the SDK re-fetches the URL with the new hash
and patches the DOM (Contentstack, `ssr: true`). That is enough for most
components. Keystroke-level updates need Recipe B.

### Recipe B — Next.js Client Component (keystroke-level updates)

```tsx
"use client";
import { useFieldTags } from "@/components/live-preview/context";
import { useLiveEntry } from "@/components/live-preview/useLiveEntry";

export default function Hero({ hero }: { hero: Entry }) {
  const live = useLiveEntry(hero); // R3 — raw entry in, live entry out
  const tag = useFieldTags(live); // R4 — tags follow the live identity
  // Optional nested record: hooks cannot be conditional, and useFieldTags
  // returns a disabled tagger for null/undefined, so no extra component.
  const imageTag = useFieldTags(live.image);

  return (
    <section>
      {live.title ? <h1 {...tag("title")}>{live.title}</h1> : null}
      {live.body ? <p {...tag("body")}>{live.body}</p> : null}
      {live.image?.url ? (
        <img
          {...imageTag("file")}
          src={live.image.url}
          alt={live.image.title ?? ""}
        />
      ) : null}
    </section>
  );
}
```

`useLiveEntry` subscribes to the SDK only inside an active session; outside
one it returns the input unchanged (the provider never starts the SDK in
production, and the raw SDK hook would throw). In a `.map()` or a callback,
use the non-hook `fieldTagsFor(useLivePreview(), item)("title")`.

Contentful: `useLiveEntry(entry, { query })` — passing the GraphQL
`DocumentNode` the entry came from makes updates faster and exact; without it
the SDK resolves fields by `__typename` and `sys.id`. Contentstack: with
`ssr: true` the hook is a passthrough (the SDK patches the DOM); with
`ssr: false` pass `refetch` and send `ContentstackLivePreview.hash` in it.

A Client Component cannot receive a render-prop or a component function from a
Server Component. Pass data.

### Recipe C — Nuxt component

```vue
<script setup lang="ts">
const props = defineProps<{ hero: Entry }>(); // R2 shape as above
const live = useLiveEntry(toRef(props, "hero")); // R3
const tag = useFieldTags(live); // R4
</script>

<template>
  <section>
    <h1 v-if="live.title" v-bind="tag('title')">{{ live.title }}</h1>
    <p v-if="live.body" v-bind="tag('body')">{{ live.body }}</p>
    <ul v-bind="tag('cta')">
      <li v-for="cta in live.ctaCollection?.items" :key="cta.sys.id">
        <NuxtLink v-bind="useFieldTags(cta)('label')" :to="cta.href">{{
          cta.label
        }}</NuxtLink>
      </li>
    </ul>
  </section>
</template>
```

The page fetches on the server with the preview state:

```ts
const event = useRequestEvent();
const { data } = await useAsyncData(
  "page",
  () => $fetch("/api/page", { query: useRoute().query }), // or call the server util directly
);
```

In a server route: `const state = previewStateFor(event)` then
`contentfulGraphql(query, variables, state)` / `contentstackGraphql(...)`.

### Contentful specifics

| Situation                   | Do this                                                                                                                                                                                                                                                 |
| --------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Field id                    | The field's **API id** (`heroTitle`), not its display name. GraphQL collection `xCollection` → field id `x` (`contentfulFieldId("xCollection")`).                                                                                                       |
| Rich text                   | Tag the wrapper that renders the document: `<div {...tag("body")}>`. Embedded entries inside render their own components with their own tags.                                                                                                           |
| Asset (image, file)         | `previewTags(state, asset)("file")` / `useFieldTags(asset)("file")` on the `<img>`/wrapper; `("title")` or `("description")` for alt text you render. An optional asset needs no guard: a `null`/`undefined` record yields a tagger that emits nothing. |
| Reference (single)          | Tag the referenced entry's fields with **its** identity. Tag the parent's field id on the wrapper for "which field holds this".                                                                                                                         |
| Reference list / collection | Wrapper gets the parent's field id; each item gets its own identity.                                                                                                                                                                                    |
| Locale                      | Default `en-US`; per-page locale via `getLivePreviewClientConfig(locale)` and `previewTags(state, entry, { locale })`.                                                                                                                                  |
| GraphQL query shape         | `sys { id }` + `__typename` at every level; declare `$preview: Boolean` and pass `(preview: $preview)` — the helper injects `preview: state.active`.                                                                                                    |
| REST                        | `include` deep enough that references arrive resolved with `sys.id` and `sys.contentType`; select fields raw.                                                                                                                                           |
| Verify data shape           | `contentfulLiveUpdateIssues(data, "graphql"                                                                                                                                                                                                             | "rest")`returns`[]` when live updates can work. Use it in a test for the page query. |
| Preview mode                | Next: draft mode **only** (the marker cookie is ignored there — a forgeable cookie must not flip a CDN-cached page into preview). Nuxt: the detection cookie. Nothing in the URL marks preview; do not add `?preview=true` checks.                      |

### Contentstack specifics

| Situation              | Do this                                                                                                                                                                                                                                          |
| ---------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Field path             | Dot path from the entry root: `title`, `seo.meta_title`, `cards.0.title`, `blocks.0.hero.heading` (`blocks[0]` is `{ hero: {...} }`).                                                                                                            |
| Modular blocks         | Tag the list container with `blocks`; each block's fields with `blocks.<i>.<block_uid>.<field>`. Empty list → R6 marker on the container.                                                                                                        |
| Group / multiple group | `group.field`, `groups.<i>.field`.                                                                                                                                                                                                               |
| Reference              | Referenced entries restart the path with **their own** `uid`/`content_type_uid`: `previewTags(state, ref)("title")`. Parent field: `tag("related")`.                                                                                             |
| GraphQL connections    | `heroConnection.edges[0].node` → path `hero.0`; use `contentstackFieldPath("heroConnection", "edges", 0, "node", "heading")` → `hero.0.heading`.                                                                                                 |
| JSON RTE               | Tag the wrapper that renders the document with the field path.                                                                                                                                                                                   |
| Asset / file field     | Tag the `<img>` or wrapper with the field path (`image`).                                                                                                                                                                                        |
| Locale                 | Lowercase in the tag (`en-us`); taken from the entry, else `defaultLocale`, else `?locale=`.                                                                                                                                                     |
| `$` maps               | If the codebase already uses `addEditableTags` (`@contentstack/utils`) or `attachEditableTags` (this package), spread `entry.$.field` / `editableTag(entry, "field")` — same attribute, same rules. GraphQL responses need `attachEditableTags`. |
| Visual Builder         | Same tags. `?builder=true` switches the SDK to builder mode; the provider carries it across links. Test both surfaces.                                                                                                                           |
| SSR vs CSR             | `ssr: true` (default): nothing to do in components. `ssr: false`: `useLiveEntry(entry, refetch)` where `refetch` sends `ContentstackLivePreview.hash`.                                                                                           |
| Preview mode           | The `live_preview` hash in the URL. The page **must** pass `searchParams` to `getPreviewState`, or nested components see production.                                                                                                             |

---

## Skill 3 — Retrofit an existing component

1. Find every place a CMS value reaches the DOM. Each becomes one tagged
   element (R1). Text in `aria-label`, `alt`, `title` attributes counts:
   tag the element that carries the attribute.
2. Check the data it receives against R2 and R3. If props are pre-shaped
   (`heading`, `imageUrl`), widen them to the raw record or add the identity
   fields alongside; then fix the query.
3. Add `state` (Server Component) or `useFieldTags` (Client / Vue) per the
   recipes. Don't switch a Server Component to `"use client"` just to tag it.
4. Lists: wrapper tag + per-item tags; Contentstack empty-list marker (R6).
5. Run the verification protocol (Skill 4) on one entry that uses the
   component.

---

## Skill 4 — Verify in the editor

Do these in order; each step isolates a layer.

1. **Frame.** Open an entry → preview. The site renders inside the panel.
   Blank panel → `frame-ancestors` / `X-Frame-Options` (Skill 1 step 1), or
   the preview URL points at the wrong host/path.
2. **Preview data.** A field changed but unsaved in the entry shows the draft
   value on load. Shows published value → the fetch is not preview-aware
   (Skill 1 step 3), or Contentful draft mode was not enabled (secret / route),
   or Contentstack `searchParams` never reached `getPreviewState`.
3. **Inspector / edit tags.** Hover a rendered field → an outline and Edit
   button appear. Missing on one field → that element is untagged or tagged
   with the wrong field id/path. Missing everywhere → tag policy is
   `preview-only` and the state is inactive, or the provider is not rendered.
4. **Live updates.** Type in the field. Text changes within a second
   (Client/Vue) or on save (Server Component). No change → R2/R3 violated;
   run `contentfulLiveUpdateIssues`, or check Contentstack `ssr`/`hash`.
5. **Navigation.** Click an internal link inside the panel. Still in preview
   (Contentstack params still in the URL) → OK. Dropped → a custom link
   bypasses the provider's click handler (R7).
6. **Production.** Load the same page without preview. `view-source` shows
   **no** `data-contentful-*` / `data-cslp` attributes and no SDK request.

Report what you verified and what you could not (no CMS access, no deployed
URL). Do not claim "live preview works" from code inspection alone.

---

## Skill 5 — Diagnose

| Symptom                                               | Likely cause                                                                                                                                                                                                                                                                                                       |
| ----------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Preview panel blank / "refused to connect"            | `X-Frame-Options` or CSP without the editor origin; host-level header; wrong region origin.                                                                                                                                                                                                                        |
| Contentful: page shows published content in preview   | Draft mode not enabled: wrong secret, route not deployed, cookie blocked (`SameSite=None; Secure` needed in the frame).                                                                                                                                                                                            |
| Contentful: status dialog says both features Disabled | Page rendered as production inside the frame: `next dev` cookie is `SameSite=Lax` (enable route must re-issue it), stale session after restart/deploy (`staleDraftCookie`), or third-party cookies blocked. Console check in the iframe context: `document.querySelectorAll("[data-contentful-entry-id]").length`. |
| `Live updates are not initialized` in production      | `useContentfulLiveUpdates` called without `skip` outside a session; use the generated `useLiveEntry`.                                                                                                                                                                                                              |
| Type error in `next.config.ts`                        | Package older than 0.4; `withLivePreview` now types as `Promise<NextConfig>`.                                                                                                                                                                                                                                      |
| Build fails without env vars                          | Environment read at module scope; the generated server module reads it per call and returns `null` client config.                                                                                                                                                                                                  |
| Contentful: one collection field never updates live   | Flattened before `useLiveEntry` (R3).                                                                                                                                                                                                                                                                              |
| Contentstack: page shows published content in preview | `searchParams` not passed to `getPreviewState`; fetch not using preview host/hash/token; cached response.                                                                                                                                                                                                          |
| Edit button on some fields only                       | Untagged elements or wrong field id/path; a wrapper tagged instead of the element (R1).                                                                                                                                                                                                                            |
| Edit button nowhere                                   | Tag policy suppressing (state inactive), provider missing, SDK not initialized (check console with `debugMode`/`debug`).                                                                                                                                                                                           |
| Contentful: "Live updates: Disabled" in the panel     | Data missing `sys.id`/`__typename` or transformed before the hook; Content Source Maps passed with an empty mapping.                                                                                                                                                                                               |
| Contentful: updates arrive only after ~5 s            | Server Component path (refresh on save). Expected; use Recipe B for keystroke updates.                                                                                                                                                                                                                             |
| Contentstack: updates stop after the first edit       | `ssr: false` without re-sending the new `hash`; or `router.refresh()` with a stale URL.                                                                                                                                                                                                                            |
| Contentstack: "Add block" missing on empty list       | R6 marker class missing or container not rendered when empty.                                                                                                                                                                                                                                                      |
| Navigation leaves preview                             | Custom anchor/`location.assign` bypassing the click handler; external redirect in between.                                                                                                                                                                                                                         |
| Tags visible in production HTML                       | `tags.policy: "always"` or a hand-written attribute.                                                                                                                                                                                                                                                               |
| Hydration mismatch in preview                         | Tags computed differently on server and client: locale or `active` differ. Pass the same `state`/locale both sides.                                                                                                                                                                                                |

---

## Anti-patterns — never do these

- Hand-writing `data-contentful-entry-id` / `data-cslp` attributes.
- Initializing `ContentfulLivePreview` / `ContentstackLivePreview` anywhere
  but the generated provider/plugin, or more than once.
- Adding `NEXT_PUBLIC_*` (or `runtimeConfig.public`) copies of tokens or the
  preview secret.
- Detecting preview from `?preview=true` unless `detection.queryParameter` is
  deliberately configured behind authentication.
- Transforming or flattening CMS records before they reach `useLiveEntry`.
- Turning a Server Component into a Client Component only to add tags.
- Caching a CMS response while the preview state is active.
- Redirecting away from the requested URL during preview.
- Claiming the editor experience works without running Skill 4.

---

## Definition of done

- [ ] Every rendered CMS field is tagged on the element that renders it (R1).
- [ ] Every record rendered carries identity fields; the query selects them (R2).
- [ ] Raw records reach the component; display transforms happen in render (R3).
- [ ] Tags come from `previewTags` / `useFieldTags` / `tagsFor` (R4).
- [ ] Preview state comes from the request and is passed, not recomputed (R5).
- [ ] Contentstack empty lists carry the empty-block marker (R6).
- [ ] No token, secret, or SDK init added outside the generated files (R8, R10).
- [ ] Production render has no tags and no SDK request (R8).
- [ ] Skill 4 steps 1–6 performed and reported, with what could not be checked.

---

## API quick reference

Core (`@eight25-factory/live-preview`):

| Function                                          | Use                                                                    |
| ------------------------------------------------- | ---------------------------------------------------------------------- |
| `parseLivePreviewConfig(input)`                   | Validate `live-preview.config.mjs`. Unknown keys throw.                |
| `resolvePreviewState(config, signals)`            | Decide preview/production from query, cookies, draft mode.             |
| `tagsFor(config, state, entry, options?)`         | Server tagger bound to a record: `tag("field")` → attributes or `{}`.  |
| `clientTagsFor(client, entry, options?)`          | Same, from the serialized client config (browser).                     |
| `fieldTagAttributes(config, state, input)`        | One tag from explicit ids when you have no record object.              |
| `entryIdentityOf(provider, entry)`                | What identity the tagger will use; `undefined` if the record has none. |
| `withPreviewParams(href, config, state)`          | Append session params to a same-site URL.                              |
| `livePreviewSecurityHeaders(config, existingCsp)` | `frame-ancestors` merged into an existing CSP.                         |
| `hydrateContentstackClient(client, search)`       | Browser-side activation from `window.location.search`.                 |

Contentful (`/contentful`): `contentfulEnvironmentFromEnv`, `contentfulClientOptions`,
`contentfulGraphqlUrl`, `contentfulRequestHeaders`, `contentfulFieldId`,
`contentfulLiveUpdateIssues`, `contentfulLivePreviewInitConfig`,
`resolveEnableDraftRequest`, `contentfulPreviewUrlTemplate`.

Contentstack (`/contentstack`): `contentstackEnvironmentFromEnv`,
`contentstackStackConfig`, `contentstackLivePreviewQuery`,
`contentstackGraphqlUrl`, `contentstackRestBaseUrl`, `contentstackRequestHeaders`,
`contentstackFieldPath`, `attachEditableTags`, `editableTag`,
`emptyBlockParentProps`, `contentstackLivePreviewInitConfig`.

Next (`/next`): `withLivePreview`, `nextPreviewState`, `livePreviewClientConfig`,
`createEnableDraftHandler` (with the `cookies` hook and `draftCookie` options),
`createDisableDraftHandler`, `nextFetchCacheOptions`, `isDraftModeRequest`,
`applyPreviewCacheHeaders`, `DRAFT_MODE_COOKIE_NAME`, `framedDraftCookie`.

Nuxt (`/nuxt`): `loadNuxtLivePreview`, `livePreviewPublicRuntimeConfig`,
`nuxtPreviewState`, `nuxtPreviewCookie`, `livePreviewNuxtClientState`,
`livePreviewRouteRules`.

Generated in the app: `getPreviewState`, `previewTags`, `getLivePreviewClientConfig`
(`null` when unconfigured), `contentfulServerEnvironment` /
`contentstackServerEnvironment`, `contentfulGraphql` / `contentstackGraphql` /
`contentstackRest` (unless `--no-fetch-helpers`), `LivePreviewProvider`,
`StalePreviewNotice`, `useLivePreview`, `useFieldTags`, `fieldTagsFor`,
`useLiveEntry` (Next); `previewStateFor`, `previewTags`, `clientStateFor`,
`useLivePreview`, `useFieldTags`, `useLiveEntry` (Nuxt).

CLI: `npx live-preview init [--write] [--no-fetch-helpers] [--no-patch]`,
`check-env`, `install-skills`, `create-component <Name> [--client] [--fields a,b]`,
`doctor <base-url>`, `print-skill`.
